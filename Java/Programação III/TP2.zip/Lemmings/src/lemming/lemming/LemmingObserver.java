package lemming.lemming;

public interface LemmingObserver {
	void lemmingMorreu(Lemming lemming);

    void lemmingSaiu(Lemming lemming);
	
}
