package experiencias;

import java.time.LocalDate;

public interface Experiencia {

	long precoAPagar(int dias);

	boolean podeReservarExcursao(LocalDate diaPartida);
	
	void setPrecoBase(long precoBase);

	String getNome();

	long getPrecoBase();
	
	boolean permiteCancelar();
}