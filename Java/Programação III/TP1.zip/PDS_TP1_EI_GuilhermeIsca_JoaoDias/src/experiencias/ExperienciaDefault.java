package experiencias;

import java.time.LocalDate;

public abstract class ExperienciaDefault implements Experiencia {

	 
	    protected long precoBase;

	    public ExperienciaDefault() {
	        
	        setPrecoBase(precoBase);
	    }
	    
	    public void setPrecoBase(long precoBase) {
	    	this.precoBase=precoBase;
	    }

	    public abstract String getNome();
	        
	    

	    public long getPrecoBase() {
	        return precoBase;
	    }

	    // Método abstrato para calcular o preço total da experiência
	    public long precoAPagar(int duracaoEmDias) {
	    	return precoBase;
	    };
	    
	    public  boolean permiteCancelar() {
	    	return false;
	    }
	    
	    public boolean podeReservarExcursao(LocalDate diaPartida) {
	    	return true;
	    }

	}

	
	

