package experiencias;

import java.time.LocalDate;

public class Aurea extends ExperienciaDefault {

	private static final long PRECO_MAXIMO_ADICIONAL = 350;

    public Aurea() {
        super();
    }

    @Override
    public long precoAPagar(int duracaoEmDias) {
        // O preço total para a ExperienciaAurea é o preço base mais 50€ por dia até um máximo de 350€
        long precoTotal = getPrecoBase() + 50 * duracaoEmDias;
        if (precoTotal > getPrecoBase() + PRECO_MAXIMO_ADICIONAL) {
            precoTotal = getPrecoBase() + PRECO_MAXIMO_ADICIONAL;
        }

        return precoTotal;
    }
	@Override
	public boolean podeReservarExcursao(LocalDate diaPartida) {
		// TODO Auto-generated method stub
		return true;
	}
	
	

	@Override
	public String getNome() {
		// TODO Auto-generated method stub
	 return "Experiencia Aurea";
	}
	
	public  boolean permiteCancelar() {
    	return true;
    }

	

}
