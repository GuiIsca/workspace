package experiencias;

import java.time.LocalDate;

public class YatchClub extends ExperienciaDefault {
	 
	private static final long PRECO_ADICIONAL_MENOS_7_DIAS = 80;
	 private static final long PRECO_ADICIONAL_MAIS_7_DIAS = 50;

	public YatchClub() {
		super();
	}

	

	@Override
	public boolean podeReservarExcursao(LocalDate diaPartida) {
		// TODO Auto-generated method stub
		return true;
	}
	public String toString() {
        return "ExperienciaYatchClub";
    }

	@Override
	public String getNome() {
		// TODO Auto-generated method stub
		return "Experiência Yatch Club";
	}
	
	public  boolean permiteCancelar() {
    	return true;
    }

	@Override
	public long precoAPagar(int duracaoEmDias) {
		// TODO Auto-generated method stub
		
        if (duracaoEmDias <= 7) {
            return (getPrecoBase() + PRECO_ADICIONAL_MENOS_7_DIAS * duracaoEmDias);
        } else {
            return (getPrecoBase() + PRECO_ADICIONAL_MAIS_7_DIAS * duracaoEmDias);
        }
    }



	
	}

