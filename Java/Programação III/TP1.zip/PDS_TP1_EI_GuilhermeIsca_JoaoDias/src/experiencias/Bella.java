package experiencias;

import java.time.LocalDate;

public class Bella extends ExperienciaDefault {

	public Bella() {
        super();
    }



	public String getNome() {
        return "Experiencia Bella";
    }

	

	

	

	
}
