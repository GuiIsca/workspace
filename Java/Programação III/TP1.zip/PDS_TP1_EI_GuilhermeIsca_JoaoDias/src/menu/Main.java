package menu;

import java.awt.Dimension;
import java.awt.GraphicsConfiguration;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import albicruises.AlbiCruises;
import albicruises.Cruzeiro;
import albicruises.Escala;
import albicruises.Excursao;
import albicruises.Porto;
import experiencias.Aurea;
import experiencias.Bella;
import experiencias.Experiencia;
import experiencias.ExperienciaDefault;
import experiencias.YatchClub;

public class Main {

	/** Arranca com a aplicação 
	 */
	public static void main(String[] args) {
		
		
		// ler os ficheiros
		readPortos( "portos.txt" );
		readCruzeiros( "cruzeiros.txt" );
		 
		 
		
		
		// criar as janelas 
		JanelaEscolhaCruzeiros je = new JanelaEscolhaCruzeiros( );
		JanelaGestaoReservas jr = new JanelaGestaoReservas( );
		
		// posicioná-las
		Dimension d = Toolkit.getDefaultToolkit().getScreenSize(); // ver a dimensão do écan
		Rectangle r1 = je.getBounds();
		Rectangle r2 = jr.getBounds();
		int posx1 = (d.width - r1.width - r2.width - 10)/2;
		int posx2 = posx1 + r1.width + 10;
		int posy = (d.height - Math.max(r1.height,r2.height))/2;

		// apresentá-las
		je.setLocation( posx1, posy );
		je.setVisible( true );
		jr.setLocation( posx2, posy );
		jr.setVisible( true );
	}

	
	/** lê o ficheiros com a informação dos portos
	 * @param portosFile come do ficheiro com a informação dos portos
	 */
	public static ArrayList<Porto> readPortos( String portosFile ) {
		 ArrayList<Porto> portos = new ArrayList<Porto>();
		
        try (BufferedReader fin = new BufferedReader(new FileReader(portosFile))) {
            String line;
            while ((line = fin.readLine()) != null) {
                String[] portoInfos = line.split("\t");
              
                String codigo = portoInfos[0];
                String nome = portoInfos[1];

                Porto porto = new Porto(codigo, nome);
                
                portos.add(porto);
                
                }
            
        } catch (FileNotFoundException e) {
            System.out.println("Não tenho o ficheiro " + portosFile);
            System.exit(0);
        } catch (IOException e) {
            System.out.println("Erro na leitura do ficheiro " + portosFile);
            e.printStackTrace();
            System.exit(0);
        }
		return portos;
		
	
	}
				
		

	/** Lê os ficheiros com a infrmação dos cruzeiros
	 * @param file nome do ficheiro com a informação dos cruzeiros
	 */
	static ArrayList<Cruzeiro> readCruzeiros( String file ){
	// fromatos em que estão as datas e horas
	final DateTimeFormatter formatterData = DateTimeFormatter.ofPattern("dd/MM/yyyy");
	final DateTimeFormatter formatterHora = DateTimeFormatter.ofPattern("H:m:s");
	ArrayList<Cruzeiro> cruzeiros = new ArrayList<Cruzeiro>();
	ArrayList<Porto> portos = readPortos( "portos.txt" );
	

	
		try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            // Ler a quantidade de cruzeiros
            int numCruzeiros = Integer.parseInt(br.readLine());
          

            // Iterar sobre cada cruzeiro
            for (int i = 0; i < numCruzeiros; i++) {
                // Ignorar a linha separadora
                br.readLine();

                // Ler informações do cruzeiro
                String[] cruzeiroInfo = br.readLine().split("\t");
                int idCruzeiro = Integer.parseInt(cruzeiroInfo[0]);
                String nomeCruzeiro = cruzeiroInfo[1];
                LocalDate dataPartida = LocalDate.parse(cruzeiroInfo[2], formatterData);
                int numCamarotes = Integer.parseInt(cruzeiroInfo[3]);
                long precoBase = Long.parseLong(cruzeiroInfo[4]);
                int numEscalas = Integer.parseInt(cruzeiroInfo[5]);

//                System.out.println("Cruzeiro #" + idCruzeiro);
//                System.out.println("Nome: " + nomeCruzeiro);
//                System.out.println("Data de Partida: " + dataPartida);
//                System.out.println("Número de Camarotes: " + numCamarotes);
//                System.out.println("Preço Base: " + precoBase);
//                System.out.println("Número de Escalas: " + numEscalas);

                Cruzeiro cruzeiro = new Cruzeiro(idCruzeiro, nomeCruzeiro, dataPartida, numCamarotes, precoBase, numEscalas);
             
               
                // Ler e imprimir experiências disponibilizadas
                String[] experiencias = br.readLine().split("\t");
                
               
                for (int n = 0; n < experiencias.length; n++) {
                    Experiencia experiencia = null;

                    if ("Bella".equals(experiencias[n])) {
                        experiencia = new Bella();
                    } if ("Aurea".equals(experiencias[n])) {
                        experiencia = new Aurea();
                    } if ("Yatch".equals(experiencias[n])) {
                        experiencia = new YatchClub();
                    }
                    	experiencia.setPrecoBase(precoBase);
                        cruzeiro.addExperiencia(experiencia);
                       // System.out.println("Experiências: " + experiencia);
                    
                }
               
                

                // Iterar sobre cada escala
                for (int j = 0; j < numEscalas; j++) {
                    // Ler informações da escala
                    String[] escalaInfo = br.readLine().split("\t");
                    int dia = Integer.parseInt(escalaInfo[0]);
                    String portoCodigo = escalaInfo[1];  
                    LocalTime horaChegada = escalaInfo[2].equals("-") ? null : LocalTime.parse(escalaInfo[2], formatterHora);
                    LocalTime horaPartida = escalaInfo[3].equals("-") ? null : LocalTime.parse(escalaInfo[3], formatterHora);
                    int numExcursões = Integer.parseInt(escalaInfo[4]);
                    Porto p;
                    //Encontrar o porto pelo código
                    for (Porto porto: portos) {
                    	if(porto.getCodigo().equals(portoCodigo))
                    		// System.out.println("Porto encontrado: " + porto);
                    		cruzeiro.addPorto(porto);
                    }
                    
                    //retornar o porto 
                    p=cruzeiro.getPortoCodigo(portoCodigo);
                    //System.out.println("Porto retornado: " + p);
               // Imprimir informações da escala
//                  System.out.println("Escala #" + (j + 1));
//                  System.out.println("Dia: " + dia);
//                  System.out.println("Porto: " + p);
//                  System.out.println("Hora de Chegada: " + horaChegada);
//                  System.out.println("Hora de Partida: " + horaPartida);
//                  System.out.println("Número de Excursões: " + numExcursões);
                 
                  Escala escala = new Escala(dia,p,horaChegada,horaPartida,numExcursões);
                  
                  cruzeiro.addEscala(escala);

                    // Iterar sobre cada excursão
                    for (int k = 0; k < numExcursões; k++) {
                        // Ler informações da excursão
                        String[] excursaoInfo = br.readLine().split("\t");
                        String nomeExcursao = excursaoInfo[0];
                        long precoExcursao = Long.parseLong(excursaoInfo[1]);
                        int numLugares = Integer.parseInt(excursaoInfo[2]);

                        // Imprimir informações da excursão
//                        System.out.println("Excursão #" + (k + 1));
//                        System.out.println("Nome: " + nomeExcursao);
//                        System.out.println("Preço: " + precoExcursao);
//                        System.out.println("Número de Lugares: " + numLugares);
//                        
                        Excursao excursao = new Excursao(nomeExcursao,precoExcursao,numLugares);
                        escala.addExcursao(excursao);
                    }
                }
               cruzeiros.add(cruzeiro) ;
            }
			
		} catch (FileNotFoundException e) {
			System.out.println("Não tenho o ficheiro " + file );
			System.exit( 0 );
		}
		catch (Exception e) {
			System.out.println("Erro na leitura do ficheiro " + file );
			e.printStackTrace();
			System.exit( 0 );
		}
		return cruzeiros;
	}
	
	
}		 


