package albicruises;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Escala {	
int dia;
Porto porto;
LocalTime horaChegada;
LocalTime horaPartida;
int nExcursoes;
ArrayList<Excursao> excursoes = new ArrayList<Excursao>();

    public Escala(int dia,Porto porto, LocalTime horaChegada, LocalTime horaPartida, int nExcursoes) {
    	this.dia=dia;
        this.horaChegada = horaChegada;
        this.horaPartida = horaPartida;
        this.porto = porto;
        this.nExcursoes = nExcursoes;
    }
   
    public void addExcursao(Excursao e) {
    	excursoes.add(e);
    }

	public Porto getPorto() {
		return porto;
	}

	public void setPorto(Porto porto) {
		this.porto = porto;
	}

	public LocalTime getHoraChegada() {
		return horaChegada;
	}

	public void setHoraChegada(LocalTime horaChegada) {
		this.horaChegada = horaChegada;
	}

	public LocalTime getHoraPartida() {
		return horaPartida;
	}

	public void setHoraPartida(LocalTime horaPartida) {
		this.horaPartida = horaPartida;
	}

	public int getnExcursoes() {
		return nExcursoes;
	}

	public void setnExcursoes(int nExcursoes) {
		this.nExcursoes = nExcursoes;
	}

	public ArrayList<Excursao> getExcursoes() {
		return excursoes;
	}

	public void setExcursoes(ArrayList<Excursao> excursoes) {
		this.excursoes = excursoes;
	}
	
	public int getDia() {
		return this.dia;
	}

	@Override
	public String toString() {
		return "Escala [porto=" + porto + ", horaChegada=" + horaChegada + ", horaPartida=" + horaPartida
				+ ", nExcursoes=" + nExcursoes + "]";
	}
	
	
    
    
    
    
}
