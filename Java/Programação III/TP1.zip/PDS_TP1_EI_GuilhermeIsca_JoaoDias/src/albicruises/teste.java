package albicruises;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class teste {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
	
	readCruzeiros("cruzeiros.txt");
		
}
	private static ArrayList<Porto> readPortos( String portosFile ) {
		ArrayList<Porto> portos = new ArrayList<Porto>();
		

       try (BufferedReader fin = new BufferedReader(new FileReader(portosFile))) {
           String line;
           while ((line = fin.readLine()) != null) {
               String[] portoInfos = line.split("\t");

               
               String codigo =portoInfos[0];
               String nome = portoInfos[1];

               Porto porto = new Porto(codigo, nome);
               portos.add(porto);
               }
           
       } catch (FileNotFoundException e) {
           System.out.println("Não tenho o ficheiro " + portosFile);
           System.exit(0);
       } catch (IOException e) {
           System.out.println("Erro na leitura do ficheiro " + portosFile);
           e.printStackTrace();
           System.exit(0);
       }
       
       return portos;	
}	
	private static void readCruzeiros( String file ) {
		try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            // Ler a quantidade de cruzeiros
            int numCruzeiros = Integer.parseInt(br.readLine());
          

            // Iterar sobre cada cruzeiro
            for (int i = 0; i < numCruzeiros; i++) {
                // Ignorar a linha separadora
                br.readLine();

                // Ler informações do cruzeiro
                String[] cruzeiroInfo = br.readLine().split("\t");
                String id = cruzeiroInfo[0];
                String nome = cruzeiroInfo[1];
                String dataPartida = cruzeiroInfo[2];
                int numCamarotes = Integer.parseInt(cruzeiroInfo[3]);
                double precoBase = Double.parseDouble(cruzeiroInfo[4]);
                int numEscalas = Integer.parseInt(cruzeiroInfo[5]);

                // Imprimir informações do cruzeiro
                System.out.println("Cruzeiro #" + id);
                System.out.println("Nome: " + nome);
                System.out.println("Data de Partida: " + dataPartida);
                System.out.println("Número de Camarotes: " + numCamarotes);
                System.out.println("Preço Base: " + precoBase);
                System.out.println("Número de Escalas: " + numEscalas);

                // Ler e imprimir experiências disponibilizadas
                String experiencias = br.readLine();
                System.out.println("Experiências: " + experiencias);

                // Iterar sobre cada escala
                for (int j = 0; j < numEscalas; j++) {
                    // Ler informações da escala
                    String[] escalaInfo = br.readLine().split("\t");
                    String dia = escalaInfo[0];
                    String porto = escalaInfo[1];
                    String horaChegada = escalaInfo[2];
                    String horaPartida = escalaInfo[3];
                    int numExcursões = Integer.parseInt(escalaInfo[4]);

                    // Imprimir informações da escala
                    System.out.println("Escala #" + (j + 1));
                    System.out.println("Dia: " + dia);
                    System.out.println("Porto: " + porto);
                    System.out.println("Hora de Chegada: " + horaChegada);
                    System.out.println("Hora de Partida: " + horaPartida);
                    System.out.println("Número de Excursões: " + numExcursões);

                    // Iterar sobre cada excursão
                    for (int k = 0; k < numExcursões; k++) {
                        // Ler informações da excursão
                        String[] excursaoInfo = br.readLine().split("\t");
                        String nomeExcursao = excursaoInfo[0];
                        double precoExcursao = Double.parseDouble(excursaoInfo[1]);
                        int numLugares = Integer.parseInt(excursaoInfo[2]);

                        // Imprimir informações da excursão
                        System.out.println("Excursão #" + (k + 1));
                        System.out.println("Nome: " + nomeExcursao);
                        System.out.println("Preço: " + precoExcursao);
                        System.out.println("Número de Lugares: " + numLugares);
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
	}
}


