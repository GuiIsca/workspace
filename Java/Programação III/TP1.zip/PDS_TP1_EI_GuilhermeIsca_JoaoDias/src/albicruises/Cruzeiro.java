package albicruises;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import experiencias.Experiencia;

public class Cruzeiro {
	int identificador;
	String descricao;
	LocalDate dataPartida;
	long preco;
	int duracaoEmDias;
	int nCamarotes;
	ArrayList<Escala> escalas=new ArrayList<Escala>();
	ArrayList<Porto> portos = new ArrayList<Porto>();
	ArrayList<Experiencia> experiencias = new ArrayList<Experiencia>();
	private int numCamarotesDisponiveis;
	
	public Cruzeiro() {
		
	}
	
	public Cruzeiro(int identificador, String descricao, LocalDate dataPartida,int nCamarotes, long preco, int duracao) {
	    this.identificador = identificador;
	    this.descricao = descricao;
	    this.dataPartida = dataPartida;
	    this.nCamarotes = nCamarotes;
	    this.preco = preco;
	    this.duracaoEmDias = duracao;
	    this.numCamarotesDisponiveis = nCamarotes;
	    }
	   
	
	public void addEscala(Escala e) {
		escalas.add(e);
	}
	
	public void addPorto(Porto p) {
		portos.add(p);
	}
	
	public Porto getPortoCodigo(String codigo) {
		for(Porto p : portos) {
		if (p.getCodigo().equals(codigo))
				return p;
		
		}
		return null;
	}

	public boolean reservarCamarotes(int numCamarotes) {
	        if (numCamarotes > 0 && numCamarotesDisponiveis >= numCamarotes) {
	            numCamarotesDisponiveis -= numCamarotes;
	           return true;
	        }
	           return false;
	        
	    }

	public int getNumCamarotesDisponiveis() {
	        return numCamarotesDisponiveis;
	    }
	public int getIdentificador() {
		return identificador;
	}


	public String getDescricao() {
		return descricao;
	}


	public LocalDate getDataPartida() {
		return dataPartida;
	}


	public long getPreco() {
		return preco;
	}


	public int getDuracaoEmDias() {
		return duracaoEmDias;
	}


	public int getnCamarotes() {
		return nCamarotes;
	}
	
	


	public ArrayList<Escala> getEscalas() {
		return escalas;
	}

	public Escala getEscala() {
		for(Escala e:escalas) {
			return e;
		}
		return null;
	}
	
	public ArrayList<Porto> getPortos() {
		return portos;
	}
	public Porto getPorto() {
		for(Porto p:portos) {
			return p;
		}
		return null;
	}
	
	
	
	
	public void addExperiencia(Experiencia e) {
		experiencias.add(e);
	}

	public ArrayList<Experiencia> getExperiencias() {
		
		return experiencias;
	}
	
	public boolean jaPartiu() {
		
		if(LocalDate.now().isAfter(dataPartida))
			return false;
		return true;
	}
}
