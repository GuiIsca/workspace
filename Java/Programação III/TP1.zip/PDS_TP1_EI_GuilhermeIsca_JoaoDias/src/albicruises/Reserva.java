package albicruises;

import java.util.ArrayList;
import java.util.List;

import experiencias.Experiencia;

public class Reserva {
	String idReserva;
	Cruzeiro cruzeiro;
	Experiencia experiencia;
	int numCamarotes;
	private ArrayList<Excursao> excursoes;
	
	
	 public Reserva(String idReserva,int numCamarotes, Experiencia experiencia, Cruzeiro cruzeiro) {
	        this.idReserva = idReserva;
	        this.numCamarotes = numCamarotes;
	        this.experiencia = experiencia;
	        this.cruzeiro = cruzeiro;
	        this.excursoes = new ArrayList<>();
	    }
	 
	 public String getId() {
	        return idReserva;
	    }

	    public int getNumCamarotes() {
	        return numCamarotes;
	    }

	    public Experiencia getExperiencia() {
	        return experiencia;
	    }

	    public Cruzeiro getCruzeiro() {
	        return cruzeiro;
	    }

	    public List<Excursao> getExcursoes() {
	        return excursoes;
	    }

	    public long getPrecoTotal() {
	        
	        
	        long precoExperiencia = experiencia.precoAPagar(cruzeiro.getDuracaoEmDias());
	        
	        
	        return precoExperiencia;
	    }

	    private long calcularPrecoExcursoes() {
	        long precoTotal = 0;
	        for (Excursao reservaExcursao : excursoes) {
	            precoTotal += reservaExcursao.getPrecoExcursao();
	        }
	        return precoTotal;
	    }

		@Override
		public String toString() {
			return "Reserva [idReserva=" + idReserva + ", cruzeiro=" + cruzeiro.descricao + ", experiencia=" + experiencia.getNome()
					+ ", numCamarotes=" + numCamarotes + "]";
		}
	 
	    
	 
}
