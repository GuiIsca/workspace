package albicruises;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class AlbiCruises {

	/** Gera um código alfanumérico de 6 caracteres aleatórios
	 * @return um código alfanumérico de 6 caracteres aleatórios
	 */
	private ArrayList<Cruzeiro> cruzeiros = new ArrayList<Cruzeiro>();
	private static ArrayList<Reserva> reservas = new ArrayList<Reserva>();
	
	public static String gerarReservaId() {
		return GeradorCodigos.gerarCodigo( 6 );
	}
	
	public void addCruzeiro(Cruzeiro c) {
		cruzeiros.add(c);
	}

	public ArrayList<Cruzeiro> getCruzeiros() {
		return cruzeiros;
	}
	
	public void addReserva(Reserva r) {
		reservas.add(r);
	}
	
	 public Reserva encontrarReservaPorRef(String reservaRef) {
	        for (Reserva reserva : reservas) {
	          
	            if (reserva.getId().equals(reservaRef)) {
	                return reserva;
	            }
	        }
	        return null; 
	    }
	 
	 public Reserva encontrarReservaPorIdCruzeiro(int idCruzeiro) {
	        for (Reserva reserva : reservas) {
	            if (reserva.getCruzeiro().getIdentificador() == idCruzeiro) {
	                return reserva;
	            }
	        }
	    
	        return null;
	    }

	public static ArrayList<Reserva> getReservas() {
		return reservas;
	}
	 
	
 
	 

}

