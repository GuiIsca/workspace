package albicruises;

public class Excursao {
	
	String nome;
	long precoExcursao;
	int nLuagares;
	public Excursao(String nome, long precoExcursao, int nLuagares) {
		
		this.nome = nome;
		this.precoExcursao = precoExcursao;
		this.nLuagares = nLuagares;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public long getPrecoExcursao() {
		return precoExcursao;
	}
	public void setPrecoExcursao(long precoExcursao) {
		this.precoExcursao = precoExcursao;
	}
	public int getnLuagares() {
		return nLuagares;
	}
	public void setnLuagares(int nLuagares) {
		this.nLuagares = nLuagares;
	}
	
	
	
}
