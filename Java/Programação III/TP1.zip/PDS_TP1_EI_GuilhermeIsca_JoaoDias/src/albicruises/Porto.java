package albicruises;

import java.util.ArrayList;
import java.util.List;

public class Porto {
 
String codigo;
String nome;



    public Porto(String codigo, String nome) {
        this.codigo = codigo;
        this.nome = nome;
        
    }

    public Porto(String codigo) {
        this.codigo = codigo;
        
        
    }
    
	public String getCodigo() {
		return codigo;
	}

	public String getNome() {
		return nome;
	}
	
	@Override
	public String toString() {
		return "Porto [codigo=" + codigo + ", nome=" + nome + "]";
	}
	
	
	
}
