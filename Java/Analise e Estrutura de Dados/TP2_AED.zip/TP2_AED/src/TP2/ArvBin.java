package TP2;

public class ArvBin {
	private No raiz; // raiz da árvore
	private int nElems; // nº de elementos da árvore
	public ArvBin( ) {
		nElems = 0;
		raiz = null;
	}
	private class No {
		String oElemento; 
		No esq;
		No dir;
		No pai;
		No( String novo ){
			oElemento = novo;
			esq = null;
			dir = null;
			pai = null;
		}
	}

	void inserir( String novo ) {
		No novoNo = new No( novo );
		No anterior = null;
		No actual = raiz;
		while( actual != null ) {
			anterior = actual;
			if( novo.compareTo(actual.oElemento) > 0  )
				actual = actual.dir;
			else
				actual = actual.esq;
		}
		if( raiz == null )
			raiz = novoNo;
		else if( novo.compareTo(anterior.oElemento) > 0 )
			anterior.dir = novoNo;
		else
			anterior.esq = novoNo;
		novoNo.pai = anterior;
		nElems++;
	}


	public No procura( String x ) {
		No actual = raiz;
		while( actual != null && actual.oElemento != x ){
			if( x.length() > actual.oElemento.length() )
				actual = actual.dir;
			else
				actual = actual.esq;
		}
		return actual;
	}

	String menor(No dir ) {
		No actual = raiz;
		if( raiz == null )
			return null;
		while( actual.esq != null )
			actual = actual.esq;
		return actual.oElemento;
	}

	public No menorNo(No inicio ) {
		No actual = inicio;
		if( inicio == null )
			return null;
		while( actual.esq != null )
			actual = actual.esq;

		return actual;
	}

	String maior( ){
		No actual = raiz;
		if( raiz == null )
			return null;
		while( actual.dir != null )
			actual = actual.dir;
		return actual.oElemento;
	}

	No maiorNo( No inicio){
		No actual = inicio;
		if( inicio == null )
			return null;
		while( actual.dir != null )
			actual = actual.dir;
		return actual;
	}

		public No predecessor( String valor ) {
			No pos = procura( valor );
			return predecessor( pos );
			}
		
		public No predecessor( No pos ) {
			if( pos.esq != null )
			return maiorNo( pos.esq );
			No actual = pos;
			No ancestral = actual.pai;
			while( ancestral != null && ancestral.esq == actual ) {
			actual = ancestral;
			ancestral = ancestral.pai;
			}
			return ancestral;
			}
		
	public No sucessor(String valor) {
		No pos = procura(valor);
		return sucessor(pos);
	}

	private No sucessor( No pos ) {
		if( pos.dir != null )
			return menorNo( pos.dir );
		No actual = pos;
		No ancestral = actual.pai;
		while( ancestral != null && ancestral.dir == actual ) {
			actual = ancestral;
			ancestral = ancestral.pai;
		}
		return ancestral;
	}


	public void eliminar( String x ){
		No actual, aApagar, filho, pai ;
		actual = procura( x );
		// descobrir qual o que se apaga: o actual ou o seu sucessor?
		if( actual.esq == null || actual.dir == null ) aApagar = actual;
		else aApagar = sucessor( actual );
		if( aApagar.esq != null ) filho = aApagar.esq;
		else filho = aApagar.dir;
		pai = aApagar.pai;
		if( filho != null ) filho.pai = pai;
		if( pai == null ) raiz = filho;
		else if( pai.esq == aApagar ) pai.esq = filho;
		else pai.dir = filho;
		if( aApagar != actual )
			actual.oElemento = aApagar.oElemento; // copiar também a chave se houver
		nElems--;
	}

	private void insereRec( No raiz, No novoNo ) {
		// ver se pode inserir nesta raiz
		if( raiz == null )
			this.raiz = novoNo;
		else if( novoNo.oElemento.length() > raiz.oElemento.length() && raiz.dir != null )
			insereRec( raiz.dir, novoNo );
		else if( novoNo.oElemento.length() <= raiz.oElemento.length() && raiz.esq != null )
			insereRec( raiz.esq, novoNo );
		else {
			// inserir neste nó
			if( novoNo.oElemento.length() > raiz.oElemento.length() ) raiz.dir = novoNo;
			else raiz.esq = novoNo;
			novoNo.pai = raiz;
		}
	}

	public int getSize() {
		return this.nElems;
	}

	private void listarPreOrdem( No no ){
		if( no == null )
			return;
		System.out.println( no.oElemento );
		listarPreOrdem( no.esq );
		listarPreOrdem( no.dir );
	}

	private void listarPosOrdem( No no ){
		if( no == null )
			return;
		listarPosOrdem( no.esq );
		listarPosOrdem( no.dir );
		System.out.println( no.oElemento );
	}


}