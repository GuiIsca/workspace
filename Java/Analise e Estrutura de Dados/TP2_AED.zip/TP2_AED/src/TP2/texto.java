package TP2;


import java.io.BufferedReader;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Scanner;

import javax.swing.JOptionPane;


public class texto {


	public static void main(String[] args) throws IOException {

		ArvBin minhaArvore=new ArvBin();

		Scanner teclado = new Scanner (System.in);

		char menu;
		String str;
		do {
			System.out.println(menuPrincipal()); /*exibe o menu na consola*/

			menu = teclado.next().charAt(0);

			switch(menu) {

			/* é pedido o nome do ficheiro ao utilizador e este ´
			 * é introduzido na AB */

			case '1' :

				String frase;

				File file = new File("Frei_Luiz_de_Sousa.txt");
				try {
					Scanner sc = new Scanner(file);
					while(sc.hasNextLine()) {
						frase = sc.nextLine();
						Scanner xpto = new Scanner(frase);
						while(xpto.hasNext()) {
							String temp = xpto.next();
							minhaArvore.inserir(converteEmMinuscula(temp));
						}
						xpto.close();
					}
					sc.close();

				}
				catch (FileNotFoundException e) {
					e.printStackTrace();
				}

				if(minhaArvore.getSize()>0)
					System.out.println("Ficheiro introduzido com sucesso!\n");


				break;

				/*introduzir palavras atraves da consola*/


			case '2' :
				do {	
					do {

						System.out.println("Insira uma frase: ");
						str=teclado.nextLine();

						if(minhaArvore.procura(str)==null) {
							minhaArvore.inserir(converteEmMinuscula(str));
						}
						System.out.println("Tamanho da arvore: "+minhaArvore.getSize());

					}while(str!="");
				} while(str == "");
				break;
			case '3' :

				System.out.println("Insira uma palavra: ");
				String palavraProcurar = teclado.nextLine();

				converteEmMinuscula(palavraProcurar);
				if(minhaArvore.procura(palavraProcurar)==null);
				break;

			case '4' :

				System.out.println("Insira uma palavra para remover: ");
				String palavra = teclado.nextLine();
				converteEmMinuscula(palavra);
				if(minhaArvore.procura(palavra)!=null)
					minhaArvore.eliminar(palavra);

				else
					System.out.println("Palavra não encontrada");

				long inicio,fim, duracao;
				inicio = System.nanoTime();
				fim = System.nanoTime();
				duracao = fim-inicio;
				System.out.println("A operação demorou" +duracao+"nanosegundos");

				;
				break;
			case '5' :


				break;
			case '0' :
				break;
			default:

				System.out.println("Opção Inválida!");	
			}
		} while(menu != 0);
	}


	public static String menuPrincipal() {
		return "1) Inserir texto a partir de um ficheiro\r\n"
				+ "2) Inserir texto a partir da consola\r\n"
				+ "3) Procurar Palavras\r\n"
				+ "4) Remover Palavras\r\n"
				+ "5) Balancear a Árvore\r\n"
				+ "0) Terminar";
	}


	public static String converteEmMinuscula(String str) {
		return str.toLowerCase();
	}



}










