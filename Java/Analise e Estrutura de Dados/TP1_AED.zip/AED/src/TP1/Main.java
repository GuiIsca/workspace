package TP1;

import java.util.Iterator;

/*
 * CLASSE PRINCIPAL
 * 
 * SÓ DEVEM ADICIONAR CÓDIGO NAS ZONAS IDENTIFICADAS COM COMENTÁRIOS
 * E ACONSELHA-SE A SEGUIREM OS ALGORITMOS ESPECIFICADOS
 */
public class Main {
	//-----------------------------------------------------------------------------	
	public static void main(String[] args) {	
		Carta baralho[]=criarBaralho();
		Carta j1[]=new Carta[10]; //mão de cada jogador
		Carta j2[]=new Carta[10];
		Carta j3[]=new Carta[10];
		Carta j4[]=new Carta[10];		

		System.out.println("--# BARALHO CRIADO #--\n");
		imprimirCartas(baralho);	

		baralho=retirar_8_9_10(baralho);
		System.out.println("\n\n--# BARALHO SEM 8, 9 E 10 #--\n");
		imprimirCartas(baralho);

		embaralhar(baralho);		
		System.out.println("\n\n--# BARALHO EMBARALHADO #--\n");
		imprimirCartas(baralho);		

		darCartas(baralho,j1,j2,j3,j4);
		System.out.println("\n\n--# BARALHO DISTRIBUIDO PELOS JOGADORES #--\n");		
		System.out.println("\n\n --# MÃO DO JOGADOR: 1 #--\n");
		imprimirCartas(j1);
		System.out.println("\n\n --# MÃO DO JOGADOR: 2 #--\n");
		imprimirCartas(j2);
		System.out.println("\n\n --# MÃO DO JOGADOR: 3 #--\n");
		imprimirCartas(j3);
		System.out.println("\n\n --# MÃO DO JOGADOR: 4 #--\n");
		imprimirCartas(j4);

		ordenar_jog1(j1);
		ordenar_jog2(j2);
		ordenar_jog3(j3);
		ordenar_jog4(j4);
		System.out.println("\n\nMÃO ORDENADA DO JOGADOR: 1 #--\n");
		imprimirCartas(j1);
		System.out.println("\n\nMÃO ORDENADA DO JOGADOR: 2 #--\n");
		imprimirCartas(j2);
		System.out.println("\n\nMÃO ORDENADA DO JOGADOR: 3 #--\n");
		imprimirCartas(j3);
		System.out.println("\n\nMÃO ORDENADA DO JOGADOR: 4 #--\n");
		imprimirCartas(j4);
	}
	//-----------------------------------------------------------------------------	
	public static Carta[] criarBaralho(){
		Carta bar[]=new Carta[52];
		int i=0;
		for(int n=Carta.COPAS;n<=Carta.PAUS;n++)
			for(int f=Carta.AZ;f<=Carta.REI;f++){
				bar[i]=new Carta(f,n);
				i++;
			}
		return bar;
	}
	//-----------------------------------------------------------------------------		
	public static void imprimirCartas(Carta car[]){
		for(int i=0;i<car.length;i++)System.out.println(car[i]);
	}
	//-----------------------------------------------------------------------------	
	public static void embaralhar(Carta bar[]){
		Carta[] embaralhado= embaralharVetor(bar, 30);
	}
	//-----------------------------------------------------------------------------	
	public static Carta[] retirar_8_9_10(Carta bar[]){
		Carta barNovo[]=new Carta[40];
		int i=0;
		for(int n=Carta.COPAS;n<=Carta.PAUS;n++)
			for(int f=Carta.AZ;f<=Carta.REI;f++){
				if(f!=8 && f!=9 && f!=10) {
					barNovo[i]=new Carta(f,n);
					i++;
				}
			}
		return barNovo;

	}
	//-----------------------------------------------------------------------------	
	public static void darCartas(Carta bar[],Carta j1[],Carta j2[],Carta j3[],Carta j4[]){
		do{

			for(int i=0; i<j1.length;i++) {
				j1[i]=bar[39-i];

				j2[i]=bar[29-i];

				j3[i]=bar[19-i];

				j4[i]=bar[9-i];

			}
		}while(bar.length!=40);

	}
	//-----------------------------------------------------------------------------	
	public static void ordenar_jog1(Carta j1[]){
	
		ordenaSeleccao(j1);
	}
	//-----------------------------------------------------------------------------	
	public static void ordenar_jog2(Carta j2[]){
	
		ordenaInsercaoDirecta(j2);
	}
	//-----------------------------------------------------------------------------	
	public static void ordenar_jog3(Carta j3[]){
		
		bubbleSort(j3);
	}
	//-----------------------------------------------------------------------------	
	public static void ordenar_jog4(Carta j4[]){
	
		quickSort(j4);
	}
	//-----------------------------------------------------------------------------	

	// retorna um vector embaralhado varias vezes
	public static Carta[] embaralharVetor(Carta[] bar, int numeroDeTrocas) {

		int a, b;
		Carta aux;
		for(int i=0; i<numeroDeTrocas; i++) {

			a=(int)(Math.random()*bar.length);
			b=(int)(Math.random()*bar.length);

			aux= bar[a];
			bar[a]=bar[b];
			bar[b]=aux;
		}
		return bar;
	}


	//ordena por selecao
	public static void ordenaSeleccao( Carta[] j1 ) {
		for( int i = 0; i < j1.length - 1; i++ ) {
			int min = i;
			for( int j = i + 1; j < j1.length; j++ )
				if( j1[ min ].verValorOrdem() > j1[ j ].verValorOrdem() )
					min = j;
			Carta aux = j1[ min ];
			j1[ min ] = j1[ i ];
			j1[ i ] = aux;
		}
	}

	//ordena por insercao
	public static void ordenaInsercaoDirecta( Carta[] j2 ) {
		for( int i = 1; i < j2.length; i++ ) {
			Carta x = j2[ i ];
			int j = i;
			while( j > 0 && j2[j-1].verValorOrdem() > x.verValorOrdem() ){
				j2[ j ] = j2[ j-1 ];
				j--;
			}
			j2[ j ] = x;
		}
	}

	//ordena por bubbleSort
	public static void bubbleSort( Carta[] j3 ) {
		boolean ordenado = false;
		int i = 0;
		while( i < j3.length - 1 && !ordenado ) {
			ordenado = true;
			for( int j = j3.length - 1; j > i; j-- ) {
				if( j3[ j - 1 ].verValorOrdem() > j3[ j ].verValorOrdem() ) {
					Carta aux = j3[ j - 1 ];
					j3[ j - 1 ] = j3[ j ];
					j3[ j ] = aux;
					ordenado = false;
				}
			}
			i++;
		}
	}

	public static void quickSort(Carta[] j4) {
		quickSort(j4, 0, j4.length-1);
	}

	public static void quickSort(Carta[] j4, int inicio, int fim) {
		if (inicio < fim) {
			int indice = particionar(j4, inicio, fim);
			quickSort(j4, inicio, indice-1);
			quickSort(j4, indice+1, fim);
		}
	}

	private static int particionar(Carta[] j4, int inicio, int fim) {
		Carta pivot =j4[fim];
		int i=(inicio-1);
		for (int j=inicio;j<fim;j++) {
			if (j4[j].verValorOrdem()<=pivot.verValorOrdem()) {
				i++;
				Carta aux=j4[i];
				j4[i]=j4[j];
				j4[j]=aux;
			}
		}
		Carta aux=j4[i+1];
		j4[i+1]=j4[fim];
		j4[fim]=aux;
		return i+1;
	}

}
