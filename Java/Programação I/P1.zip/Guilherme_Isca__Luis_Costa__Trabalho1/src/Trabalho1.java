
import java.util.Scanner ;

public class Trabalho1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner (System.in);

		int tamMax=100;
		String [] titulo = new String[tamMax];
		String [] autor = new String[tamMax];
		int [] paginas = new int[tamMax];
		int [] paginasLidas = new int[tamMax];
		boolean [] emprestado = new boolean[tamMax];
		int nLivros=0, i=0;

		titulo[0] = "In�s de Castro";
		autor[0] = "Isabel Stilwell";
		paginas[0] = 488;
		paginasLidas[0] = 488;
		emprestado[0] = false;

		titulo[1] = "Ast�rix e a Transit�lica";
		autor[1] = "Jean-Yves Ferri";
		paginas[1] = 46;
		paginasLidas[1] = 46;
		emprestado[1] = false;

		titulo[2] = "Ast�rix e o Grifo";
		autor[2] = "Jean-Yves Ferri";
		paginas[2] = 48;
		paginasLidas[2] = 12;
		emprestado[2] = false;

		titulo[3] = "O Jardim dos Animais com Alma";
		autor[3] = "Jos� Rodrigues dos Santos";
		paginas[3] = 504;
		paginasLidas[3] = 0;
		emprestado[3] = true;

		titulo[4] = "�ltimo Olhar";
		autor[4] = "Miguel Sousa Tavares";
		paginas[4] = 504;
		paginasLidas[4] = 0;
		emprestado[4] = true;
		nLivros=5;

		char opcao1, opcaoVisualizar, opcaoEditar, opcaoEditarLivro, opcaoLer;
		int posLivro;


		do {

			System.out.println("(V)isualizar\n(E)ditar\n(L)er\n(S)air");
			opcao1 = sc.next().charAt(0);

			switch(opcao1) { 
			case 'V' :               //(V)isualizar
				do {
					System.out.println("Visualizar (t)odos os livros\nVisualizar livros em (l)eitura\nVisualizar livros te(r)minados\nVisualizar livros (p)or ler\nVisualizar livros (e)mprestados\n(V)oltar");
					opcaoVisualizar = sc.next().charAt(0);
					switch(opcaoVisualizar) {
					case 't':            //Visualizar (t)odos os livros
						System.out.printf("%-30s %8s %30s %6s %7s","   T�tulo","Autor","P�ginas","Pag.Lidas","Emprestado");
						for(i=0;i<nLivros;i++) {

							if(emprestado[i] == true) {
								System.out.print("x");
							}


							System.out.printf("\n%d: %-30s %-25s %9s %10s %10s",i+1,titulo[i],autor[i],paginas[i],paginasLidas[i],emprestado[i]);
						}
						System.out.println();

						break;
					case 'l':            //Visualizar livros em (l)eitura
						break;	
					case 'r':            //Visualizar livros te(r)minados
						break;	
					case 'p':            //Visualizar livros (p)or ler
						break;
					case 'e':            //Visualizar livros (e)mprestados
						break;
					case 'V':            //(V)oltar
						break;
					default:
						System.out.println("Op��o Inv�lida!");	
					}
					break;
				} while(opcaoVisualizar != 'V');
			case 'E' :                   //(E)ditar
				System.out.println("Adicionar (l)ivro\nProcurar livro por (t)�tulo\nProcurar livro por (a)utor\nApagar livro por (p)osi��o\nApagar to(d)os os livros de um autor\n(E)ditar livro\n(V)oltar");
				opcaoEditar = sc.next().charAt(0);
				switch(opcaoEditar) {
				case 'l':                //Adicionar (l)ivro
					break;
				case 't':                //Procurar livro por (t)�tulo
					System.out.println("Introduza um titulo: ");
					String tituloProc = sc.next();
					sc.nextLine();
					for (i = 0; i < nLivros; i++) {
						titulo[i].indexOf(tituloProc);

						if(titulo[i].indexOf(tituloProc)==0)	{
							System.out.println(titulo[i]);
						}
					}
					break;	
				case 'a':                //Procurar livro por (a)utor
					System.out.println("Introduza um autor: ");
					String autorProc = sc.next();
					sc.nextLine();
					for (i = 0; i < nLivros; i++) {
						autor[i].indexOf(autorProc);

						if(autor[i].indexOf(autorProc)==0)	{
							System.out.println(titulo[i]);
						}
					}
					break;	
				case 'p':                 //Apagar livro por (p)osi��o
					break;	
				case 'd':                 //Apagar to(d)os os livros de um autor
					break;
				case 'E':                 //(E)ditar livro
					System.out.println("Alterar (t)�tulo\nAlterar (a)utor\nAlterar (n)�mero de p�ginas\n(V)oltar");
					opcaoEditarLivro = sc.next().charAt(0);
					switch(opcaoEditarLivro) {
					case 't':             //Alterar (t)�tulo
						System.out.println("Introduza a posi��o em que o livro se encontra: ");
						posLivro=sc.nextInt();
						sc.nextLine();
						System.out.println("Como quer que o titulo do livro se chame? ");
						String tituloAtual=sc.next();
						sc.nextLine();

						for(i=0; i < nLivros; i++) {
							if(posLivro==i) {
								titulo[i]=tituloAtual;
							}
						}	
						break;
					case 'a':             //Alterar (a)utor
						System.out.println("Introduza a posi��o em que o livro se encontra: ");
						posLivro=sc.nextInt();
						sc.nextLine();
						System.out.println("Como quer que o autor se chame? ");
						String nomeAutorAtual=sc.next();
						sc.nextLine();

						for(i=0; i < nLivros; i++) {
							if(posLivro==i) {
								autor[i]=nomeAutorAtual;
							}
						}	
						break;
					case 'n':             //Alterar (n)�mero de p�ginas
						int numPaginasAtual;
						System.out.println("Introduza a posi��o em que o livro se encontra: ");
						posLivro=sc.nextInt();
						sc.nextLine();
						System.out.println("Quantas p�ginas quer que o livro tenha? ");
						numPaginasAtual=sc.nextInt();
						sc.nextLine();

						for(i=0; i < nLivros; i++) {
							if(posLivro==i) {
								paginas[i]=numPaginasAtual;
							}
						}	
						break;
					case 'V':             //(V)oltar
						break;
					default:
						System.out.println("Op��o Inv�lida!");		
					} break;
				case 'V':                 //(V)oltar
					break;
				default:
					System.out.println("Op��o Inv�lida!");	
				}
			case 'L' :                    //(L)er
				System.out.println("Procurar livro por (t)�tulo\nProcurar livro por (a)utor\n(M)arcar como lido\nAlterar (p)�ginas lidas\n(E)mprestar livro\nMostrar (n)�mero de livros lidos\nMostrar n�mero de p�ginas (l)idas\n(V)oltar");
				opcaoLer = sc.next().charAt(0);
				switch(opcaoLer) {
				case 't':                 //Procurar livro por (t)�tulo
					System.out.println("Introduza um titulo: ");
					String tituloProc = sc.next();
					sc.nextLine();
					for (i = 0; i < nLivros; i++) {
						titulo[i].indexOf(tituloProc);

						if(titulo[i].indexOf(tituloProc)==0)	{
							System.out.println(titulo[i]);
						}
					}
					break;
				case 'a':                 //Procurar livro por (a)utor
					System.out.println("Introduza um autor: ");
					String autorProc = sc.next();
					sc.nextLine();
					for (i = 0; i < nLivros; i++) {
						autor[i].indexOf(autorProc);

						if(autor[i].indexOf(autorProc)==0)	{
							System.out.println(titulo[i]);
						}
					}
					break;
				case 'M':                 //(M)arcar como lido
					int procLido;
					System.out.println("Introduza a posi��o do livro que quer marcar como lido: ");
					procLido = sc.nextInt();
					sc.nextLine();
					for (i=0; i < nLivros; i++) {
						if(procLido==i) {
							paginasLidas[i-1]=paginas[i-1];
						}
					}
					break;
				case 'p':                 //Alterar (p)�ginas lidas
					int pagLidasAtual;
					System.out.println("Introduza a posi��o em que o livro se encontra: ");
					posLivro=sc.nextInt();
					sc.nextLine();
					System.out.println("Quantas p�ginas leu? ");
					pagLidasAtual=sc.nextInt();
					sc.nextLine();

					for(i=0; i < nLivros; i++) {
						if(posLivro==i) {
							paginasLidas[i-1]=pagLidasAtual;
						}
					}
					break;
				case 'E':       //(E)mprestar livro
					System.out.println("Vai marcar como EMPRESTADO!!\nIntroduza a posi��o em que o livro se encontra: ");
					posLivro=sc.nextInt();
					sc.nextLine();
					for(i=0; i < nLivros; i++) {
						if(posLivro==i) {
							emprestado[i-1]=true;
						}
					}
					break;
				case 'n':                 //Mostrar (n)�mero de livros lidos
					int lidos=0;
					for(i=0; i < nLivros; i++) {
						if(paginasLidas[i]==paginas[i]) {
							lidos = i+1;
						}
					}
					System.out.printf("O n�mero de livros lidos � igual a %d\n\n", lidos);		
					break;
				case 'l':                 //Mostrar n�mero de p�ginas (l)idas
					int pagLidasTotal=0;
					for(i=0; i < nLivros; i++) {
						pagLidasTotal = pagLidasTotal + paginasLidas[i];
					}
					System.out.printf("O n�mero de p�ginas lidas no total � igual a %d\n\n",pagLidasTotal);			
					break;
				case 'V':                 //(V)oltar
					break;
				default:
					System.out.println("Op��o Inv�lida!");		
				}
			}
		} while(opcao1 != 'S');           //(S)air

	}
}

