package Ficha5;

import java.util.Scanner;

public class Ex11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner (System.in);
		
		System.out.println("Introduza o nome: ");
		String nome = sc.nextLine();
		
		String temp[] = nome.split(" ");
		
	
	}

}
