package Ficha5;

import java.util.Scanner ;

public class Ex1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner teclado = new Scanner (System.in);
		int [] num= new int [10];

		for(int i=0; i < num.length; i++) {
			System.out.println("Introduza um n�mero "+ (i+1) + ":");
			num[i]=teclado.nextInt();
		}

		int soma=0;

		System.out.println("N�meros: ");
		for (int i = 0; i < num.length; i++) {
			System.out.print(num[i]+" ");
			soma = soma + num[i];
		}

		double media=((double) soma)/num.length;

		System.out.println("M�dia: " + soma + "/" +num.length+ "="+ media);

		teclado.close();

	}

}
