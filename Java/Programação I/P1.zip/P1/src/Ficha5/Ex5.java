package Ficha5;

import java.util.Scanner ;

public class Ex5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner (System.in);

		int bilhetes[] = {200,100,100,10};
		int precos[] = {20,30,40,70};
		String zonas[] = {"1�Plateia","2�Plateia","Balc�o","Camarotes"};
		int opcao;

		do {
			for (int i = 0; i < zonas.length ; i++)
				System.out.printf("%d: %s \t(%d�)\t- %3d lugares dispon�veis\n",i+1,zonas[i],precos[i],bilhetes[i]);
			System.out.println("0: Sair");

			do {
				System.out.println("Escolha uma op��o(0-4):");
				opcao = teclado.nextInt();
			}
			while(opcao<0 || opcao>4);

			if(opcao !=0) {
				System.out.println("Quantos bilhetes pretende? ");
				int quantos=teclado.nextInt();

				if(quantos>bilhetes[opcao-1]) {
					System.out.printf("Existem apenas %d bilhetes para essa zona\n\n",bilhetes);
				}
				else {
					int custo=quantos*precos[opcao-1];
					bilhetes[opcao-1]-=quantos;
					System.out.println("\nCusto total dos bilhetes: "+custo +"�\n\n");
				}
			}
			else
				System.out.println("Obrigado por nos visitar");
		} while(opcao !=0);
		teclado.close();
	}

}
