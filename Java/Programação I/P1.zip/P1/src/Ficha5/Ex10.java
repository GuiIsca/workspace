package Ficha5;

import java.util.Scanner;

public class Ex10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner (System.in);
		
		System.out.println("Introduza um nome: ");
        String nome = sc.next();
        
        System.out.println("Introduza a sua apresenta��o: ");
        String apresentacao = sc.next();
        
        int tamanho = nome.length();
        
        String nomeApresentacao[] = new String[tamanho];
        nome = nomeApresentacao[0];
        apresentacao = nomeApresentacao[1];
        
        for (int i = 0; i < nomeApresentacao.length; i++) {
			System.out.println(nomeApresentacao[i]);
		}
        
        sc.close();
	}

}
