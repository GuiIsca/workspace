package Ficha5;

import java.util.Scanner;

public class Ex2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner (System.in);

		int [] num= new int [10];

		int cont = 0 ;

		for(cont=0; cont < num.length; cont++) {
			System.out.println("Introduza um n�mero(0 para terminar):");
			num[cont]=teclado.nextInt();

			if (num[cont] == 0)
				break;

			else if (num[cont] != 0)
				continue;
			cont++;
		}

		int soma=0;

		System.out.println("N�meros: ");
		for (int i = 0; i < cont; i++) {
			System.out.print(num[i]+" ");
			soma = soma + num[i];
		}

		double media=((double) soma)/cont;

		System.out.println("M�dia: " + soma + "/" +num.length+ "="+ media);


		teclado.close();
	}

}


