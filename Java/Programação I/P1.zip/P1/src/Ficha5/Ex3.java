package Ficha5;

public class Ex3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		double notas[] = {12.3,14.9,17,13,18,9.5,7.6,10,19.3,20,15.6,11.3,13.4,17,18.9,12.8,19,14.8,6,8};

		double notaAlta = notas[0];
		double notaBaixa = notas[0];
		int Aprovados = 0;
		int Reprovados = 0;

		for (int i = 0; i < notas.length; i++) {
			if(notas[i]>notaAlta)
				notaAlta = notas[i];

			if(notas[i]<notaBaixa)
				notaBaixa = notas[i];

			if(notas[i] >= 9.5)
				Aprovados++;
			else
				Reprovados++;
		}

		System.out.println("A nota mais alta � "+notaAlta);
		System.out.println("A nota mais baixa � "+notaBaixa);
		System.out.println("A n�mero de Aprovados � "+Aprovados);
		System.out.println("A n�mero de Reprovados � "+Reprovados);

		
	}

}
