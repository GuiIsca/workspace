package Ficha5;

import java.util.Scanner;

public class Ex7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner (System.in);

		String meses[] = {"","Janeiro","Fevereiro","Mar�o","Abril","Maio","Junho","Julho","Agosto","Setembro","Outubro","Novembro","Dezembro"};

		System.out.println("Introduza a data: ");
		String data = input.next();
		
		String []temp=data.split("/");
		
		int mes= Integer.parseInt(temp[1]);
		
		System.out.println(temp[0] + " de "+ meses[mes] + " de " + temp[2]);
		
		input.close();
	}

}
