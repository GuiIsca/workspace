package Ficha5;

import java.util.Scanner;

public class Ex9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner (System.in);
		
		System.out.println("Introduza o seu nome: ");
		String nome = sc.nextLine();
		
		System.out.println("N�mero de caracteres: " + nome.length());
		
		int tamanho = nome.length();
		
		System.out.print("Primeira letra : "+nome.charAt(0)+" Ultima letra : "+nome.charAt(tamanho-1));
		
		
		
			
		}

	}

