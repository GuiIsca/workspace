package Ficha5;

public class Ex4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		double  temp[] = {35.5,34,32,31,38.9,40,33.8,30.8,35,36,38.5,41.2,42,31,29.9,31.7,40,39,39.2,36.7,34.7,33.9,38.8,33.3,34.9,32.5,38.2,30,34,32,38.2};

		double alta = temp[0];
		double baixa = temp[0];

		int diaMax= 0;
		int diaMin= 0;

		for (int i = 0; i < temp.length; i++) {

			if(temp[i]>alta)
				alta = temp[i];
			diaMax= i;

			if(temp[i]<baixa)
				baixa = temp[i];
			diaMin= i;
		}

		System.out.println("A temperatura mais alta foi "+alta+ " no dia "+diaMax );
		System.out.println("A temperatura mais baixa foi "+baixa+ "no dia "+diaMin );

		double soma=0;
		double media=0;

		for (int i = 0; i < temp.length; i++) {
			soma = soma + temp[i];
		}

		media = soma/temp.length;


		System.out.printf("M�dia: %.2f", media);

		System.out.println();

		for (int i = 0; i < temp.length; i++) {
			System.out.println("Dia"+ (i+1) + ":"+temp[i]+"�C");
			if (temp[i]==alta)
				System.out.println("maxima");
			if (temp[i]==baixa)
				System.out.println("minima");
			else if (temp[i]>media)
				System.out.println("acima da media");
			else if (temp[i]<media)
				System.out.println("abaixo da media");
			else
				System.out.println("A temperatura media �");
		}  	





	}

}
