package Ficha5;

public class Ex6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int idades[] = {15,16,14,14,17,13,18,18,19,17,20,23,22,14,17,19,17,21,20,23,22,16,18,17,20,24,16,15,23,17};
		String categorias[] = {" <=17 anos: "," 18anos: "," 19anos: "," 20anos: "," >=21anos: "};
		int cont[] = {0,0,0,0,0};

		for (int i = 0; i < idades.length; i++) {
			if(idades[i]<=17)
				cont[0]++;	
			if(idades[i]==18)
				cont[1]++;	
			if(idades[i]==19)
				cont[2]++;	
			if(idades[i]==20)
				cont[3]++;	
			if(idades[i]>=21)
				cont[4]++;	
		}
		for (int i = 0; i < categorias.length; i++) 
			System.out.println(categorias[i]+cont[i]);

		System.out.println();	
		for (int i=0; i < categorias.length; i++) { 
			System.out.print(categorias[i]);

		for (int j=0; j <cont[i]; j++) 
			System.out.print("*");
			System.out.println();

		}


	}

}
