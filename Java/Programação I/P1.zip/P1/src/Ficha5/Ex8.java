package Ficha5;

public class Ex8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	    String meses[] = {"Janeiro","Fevereiro","Mar�o","Abril","Maio","Junho","Julho","Agosto","Setembro","Outubro","Novembro","Dezembro"};
	    double lucro[] = {6000,3400,2100,1000,5000,2000,4000,3450,6000,7000,4500,7000};
	    
	    for (int i = 0; i < lucro.length; i++) {
	    	System.out.printf("%-14s - %9.2f�\n",meses[i],lucro[i]);	
		}
	 double soma = 0;
	 for (int i = 0; i < lucro.length; i++) {
		soma = soma + lucro[i];
	}
	 System.out.printf("%-12s - %9.2f","Total anual:",soma);
	 
	}

}
