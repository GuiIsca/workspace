package Ficha3;

import java.util.Scanner;

public class Ex13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
        Scanner teclado=new Scanner(System.in);
		
		System.out.println("Introduza a:");
		double a=teclado.nextDouble();
		
		System.out.println("Introduza b:");
		double b=teclado.nextDouble();
		
		System.out.println("Introduza c:");
		double c=teclado.nextDouble();
		
		double delta = b*b- 4*a*c;
		
		System.out.println("Delta = " + delta);
		
		if(delta>0)
			System.out.println("A equa��o tem duas solu��es reais.");
		else
			if(delta<0)
				System.out.println("A equa��o n�o tem solu��es reais.");
			else
				System.out.println("A equa��o tem uma solu��o real.");
				
		teclado.close();	
		
		

	}

}
