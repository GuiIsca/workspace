package Ficha3;

import java.util.Scanner;

public class Ex10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner teclado=new Scanner(System.in);

		System.out.println("Introduza o sal�rio:");
		double salario=teclado.nextDouble();
		
		double taxa=0;
		
		if( salario < 500 )
			taxa = 0;
		else if( salario < 650 )
			taxa = 0.015;          
		else if( salario < 800 )   
			taxa = 0.035;
		else if( salario < 1200 )
			taxa = 0.05;
		else if( salario < 2000 )
			taxa = 0.1;
		else if( salario < 3000 )
			taxa = 0.2;
		else
			taxa = 0.35;

		double imposto = salario * taxa; 
		double liquido = salario - imposto;
		
		System.out.printf("Para um sal�rio bruto de %.2f o imposto � %.2f e o sal�rio liquido � %.2f", salario, imposto, liquido); 
		
		teclado.close();
		

	}

}
