package Ficha3;

import java.util.Scanner;

public class Ex4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

		Scanner teclado=new Scanner(System.in);

		System.out.println("Introduza um n�mero:");
		int num=teclado.nextInt();
		
		if(num%2==0) {
			System.out.println(num + " � um n�mero par.");
		}
		else {
			System.out.println(num + " � um n�mero impar.");
		}
		
		teclado.close();
		

	}

}
