package Ficha3;

import java.util.Scanner;

public class Ex5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner teclado=new Scanner(System.in);

		System.out.println("Introduza um n�mero:");
		double num=teclado.nextDouble();
		
		double raiz=0;
		
		if(num>=0){
			raiz=Math.sqrt(num);
			System.out.println("A ra�z quadrada de " + num + " �: " + raiz);
		}
		else{
			raiz=Math.sqrt(-num);
			System.out.println("A ra�z quadrada de " + num + " �: " + raiz + "i");
		}
		teclado.close();		

	}

}
