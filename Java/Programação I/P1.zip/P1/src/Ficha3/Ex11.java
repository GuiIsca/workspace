package Ficha3;

import java.util.Scanner;

public class Ex11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner teclado=new Scanner(System.in);

		System.out.println("Introduza o dia:");
		int dia=teclado.nextInt();
		
		System.out.println("Introduza o m�s:");
		int mes=teclado.nextInt();
		
		System.out.println("Introduza o ano:");
		int ano=teclado.nextInt();

		String mesString = "";
		
		switch( mes ){
		case 1: mesString = "janeiro"; break;
		case 2: mesString = "fevereiro"; break;
		case 3: mesString = "mar�o"; break;
		case 4: mesString = "abril"; break;
		case 5: mesString = "maio"; break;
		case 6: mesString = "junho"; break;
		case 7: mesString = "julho"; break;
		case 8: mesString = "agosto"; break;
		case 9: mesString = "setembro"; break;
		case 10: mesString = "outubro"; break;				
		case 11: mesString = "novembro"; break;
		case 12: mesString = "dezembro"; break;
		default: mesString = "mes desconhecido";				
		}

		System.out.printf( "%d de %s de %d", dia, mesString, ano);

		teclado.close(); 	

	}

}
