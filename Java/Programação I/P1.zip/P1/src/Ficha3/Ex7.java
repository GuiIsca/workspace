package Ficha3;

import java.util.Scanner;

public class Ex7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner teclado=new Scanner(System.in);

		System.out.println("Introduza um ano:");
		int ano=teclado.nextInt();
		
		if((ano % 4 == 0 && ano % 100 != 0) || (ano % 400 == 0))
				
			System.out.println( ano + " � bissexto.");
		else
			System.out.println( ano + " n�o � bissexto");
		
		teclado.close();
		

	}

}
