package Ficha3;

import java.util.Scanner;

public class Ex1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner teclado=new Scanner(System.in);

		System.out.println("Introduza um n�mero:");
		
		int num=teclado.nextInt();

		int abs=num;
		
		if(num<0)
			abs=-num;
		
		System.out.println("|"+num+"|="+abs);

		teclado.close();
		
	}

}
