package Ficha3;

import java.util.Scanner;

public class Ex9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner teclado=new Scanner(System.in);

		System.out.println("Introduza a cilindrada:");
		int cilindrada=teclado.nextInt();
		
		double taxa=0, parcela =0;
		
		if( cilindrada < 1250 ){
			taxa=3.74; 
			parcela=2417.56;
		}
		else {
			taxa=8.86;
			parcela=8813.22;
		}
		
		double ia=cilindrada * taxa - parcela;
		
		ia = ia < 0 ? 0 : ia;
		
		System.out.printf( "Para uma cilindrada de %d o ia � %.2f", cilindrada, ia);
		
		teclado.close();
		
		

	}

}
