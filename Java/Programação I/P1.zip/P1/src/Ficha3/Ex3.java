package Ficha3;

import java.util.Scanner;

public class Ex3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
        Scanner teclado=new Scanner(System.in);
		
		System.out.println("Introduza um n�mero:");
		int num1=teclado.nextInt();
		
		System.out.println("Introduza outro n�mero:");
		int num2=teclado.nextInt();
		
		System.out.println("Valores introduzidos: " + num1 + " , " + num2);
				
		
		if(num1<num2){
			
			int temp=num1;
			
			num1=num2;
			num2=temp;
			System.out.println("Troquei: " + num1 + " , " + num2);
			
		}
			
		teclado.close();
		
	}

}
