package Ficha3;

import java.util.Scanner;

public class Ex2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner teclado=new Scanner(System.in);

		System.out.println("Introduza um n�mero:");
		int num=teclado.nextInt();
		
		
		if(num>100) {
			num=100;
			System.out.println("O n�mero fornecido era maior que 100: foi truncado.");
		}
		
		
		System.out.println("N�mero: " + num);

		teclado.close();
		

	}

}
