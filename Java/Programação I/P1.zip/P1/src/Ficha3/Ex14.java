package Ficha3;

import java.util.Scanner;

public class Ex14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
        Scanner teclado=new Scanner(System.in);
		
		System.out.println("Introduza a:");
		double a=teclado.nextDouble();
		
		System.out.println("Introduza b:");
		double b=teclado.nextDouble();
		
		System.out.println("Introduza c:");
		double c=teclado.nextDouble();
		
		double delta = b*b- 4*a*c;
		
		if(delta>0){
			double raiz=Math.sqrt(delta);
			double x1 = (-b+raiz)/(2*a);
			double x2 = (-b-raiz)/(2*a);
			
			System.out.printf("x = %.2f ou x = %.2f", x1, x2);
			
		}	
		else
			if(delta<0){
				double real=-b/(2*a);
				double imag=Math.sqrt(-delta)/(2*a);
				
				System.out.printf("x = %.2f + %.2fi ou x = %.2f - %.2fi", real, imag, real, imag);
				
				
			}
			else{
				double x=-b/(2*a);
				System.out.printf("x = %.2f", x);
			}	

	}

}
