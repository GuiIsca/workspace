package Ficha3;

import java.util.Scanner;

public class Ex6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner teclado=new Scanner(System.in);

		System.out.println("Introduza um caracter:");
		char c=teclado.next().charAt(0);
		
		int dif ='a'-'A';

		if(c>='a'&& c<='z'){
			
			char outroC=(char) (c - dif);
			System.out.println("A mai�scula de " + c + " � " + outroC);
		}
		else if(c>='A'&& c<='Z'){
			char outroC=(char) (c + dif);
			System.out.println("A min�scula de " + c + " � " + outroC);
		}
		else
			System.out.println(c + " n�o � uma letra.");
		
		teclado.close();
		

	}

}
