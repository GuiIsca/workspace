package Ficha3;

import java.util.Scanner;

public class Ex8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner teclado=new Scanner(System.in);

		System.out.println("Introduza um n�mero:");
		int num=teclado.nextInt();
		
		
		int abs = num<0 ? -num : num;
			
		
		System.out.println("|"+num+"|="+abs);
			
		
		// System.out.println("O n�mero " + num + " � " + ( num%2==0 ? "par" : "�mpar") );
		

		teclado.close();
		

	}

}
