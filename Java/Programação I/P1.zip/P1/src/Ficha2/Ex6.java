package Ficha2;

public class Ex6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
        int horas=1, minutos=1, segundos=1;
		
		int totalSegundos=0;
		
		totalSegundos=(3600*horas)+(60*minutos)+segundos;
		
		System.out.println(+ horas + "h" + minutos + "m" + segundos + "s = " + totalSegundos + " segundos");
		

	}

}
