package Ficha2;

public class Ex3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int valor1=10;
		int valor2=23;
		int soma=0;
		
		soma=valor1+valor2;
		
		System.out.println(valor1 + " + " + valor2 + " = " + soma);
		
		System.out.printf("%d + %d = %d\n", valor1, valor2, soma);

	}

}
