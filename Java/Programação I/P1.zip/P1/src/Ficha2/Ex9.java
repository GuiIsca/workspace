package Ficha2;

public class Ex9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int graus = 45;
		double rads = Math.toRadians(graus);
		
		double cos=Math.cos(rads);
		double sin=Math.sin(rads);
		double tan=Math.tan(rads);
		double cotan=1/tan;
		
		
		System.out.printf("cos(%d)=%.2f\n", graus, cos);
		System.out.printf("sin(%d)=%.2f\n", graus, sin);
		System.out.printf("tan(%d)=%.2f\n", graus, tan);
		System.out.printf("cotan(%d)=%.2f\n", graus, cotan);

	}

}
