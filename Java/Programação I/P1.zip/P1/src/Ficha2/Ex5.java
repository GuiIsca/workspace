package Ficha2;

public class Ex5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
        int grausCelcius = 25;
		
		double grausFahrenheit = 0;
				
		
		grausFahrenheit = 1.8*grausCelcius+32;
		
		System.out.println(grausCelcius + "� = " + grausFahrenheit + "F");
		
		System.out.printf("%d� = %.2fF\n", grausCelcius, grausFahrenheit);
		

	}

}
