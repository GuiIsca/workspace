package Ficha2;

public class Ex10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
        int x1 = 4, y1 = 10, x2 = 12, y2 = 7;
		
		double dx=x2-x1;
		double dy=y2-y1;
		
		double dist=Math.sqrt(dx*dx+dy*dy);
		
		System.out.println("Dist�ncia = " + dist);

		double m=dy/dx;
		
		double b=y1-x1*m;
		
		System.out.printf("y = %.2f*x + %.2f", m, b );

	}

}
