package Ficha2;

public class Ex8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
        int graus = 32;
		
		double grados = 0;
		double rads = 0;
		
		
		rads = Math.PI*graus/180;
		
		grados = 100.0*graus/90;
		
		System.out.printf("%d graus = %.4f radianos \n", graus, rads);
		
		System.out.printf("%d graus = %.1f grados \n", graus, grados);

	}

}
