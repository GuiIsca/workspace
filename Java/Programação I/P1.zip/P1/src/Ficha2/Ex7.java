package Ficha2;

public class Ex7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

		int totalSegundos=3661;
		
		
		int horas=0, minutos=0, segundos=0;
		int resto=0;
		
		horas=totalSegundos/3600;
		
		resto=totalSegundos%3600;
		
		minutos=resto/60;
		
		segundos=resto%60;
		
		System.out.printf("%d segundos = %02dh%02dm%02ds \n", totalSegundos, horas, minutos, segundos);

	}

}
