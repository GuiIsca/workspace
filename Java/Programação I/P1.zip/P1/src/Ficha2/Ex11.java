package Ficha2;

public class Ex11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		double precoInicial = 119.99;
		int desconto =25;
		double descontoReal = desconto/100.0;
		
		double valorDesconto = precoInicial*descontoReal;
		double precoFinal = precoInicial - valorDesconto;
		
		System.out.printf("%-14s%7.2f\n", "Preco:", precoInicial);		
		System.out.printf("%-14s%4d%%\n", "%Desconto:", desconto);
		System.out.printf("%-14s%7.2f\n", "Preco final:", precoFinal);
		System.out.printf("%-14s%7.2f\n", "Desconto:", valorDesconto);


	}

}
