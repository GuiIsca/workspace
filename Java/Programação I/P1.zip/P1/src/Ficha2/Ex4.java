package Ficha2;

public class Ex4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int num1 = 4;
		int num2 = 6;

		int produto = 0;
		int quociente = 0;
		int resto = 0;
		int quad1 = 0;
		int quad2 = 0;

		produto = num1 * num2;

		System.out.println("Produto:");
		System.out.println(num1 + " * " + num2 + " = " + produto);
		System.out.printf("%d * %d = %d", num1, num2, produto);
		System.out.println();
				
		quociente = num1 / num2;
		
		System.out.println("Quociente:");
		System.out.println(num1 + " / " + num2 + " = " + quociente);
		System.out.printf("%d / %d = %d", num1, num2, quociente);
		System.out.println();
		
		resto = num1 % num2;
		
		System.out.println("Resto:");
		System.out.println(num1 + " % " + num2 + " = " + resto);
		System.out.printf("%d %% %d = %d", num1, num2, resto);
		System.out.println();
		
		quad1 = num1 * num1;
		
		System.out.println("Quadrado do n�mero 1:");
		System.out.println(num1 + " ^ 2 = " + quad1);
		System.out.printf("%d ^ 2 = %d", num1, quad1);
		System.out.println();
		
		quad2 = num2 * num2;
		
		System.out.println("Quadrado do n�mero 1:");
		System.out.println(num2 + " ^ 2 = " + quad2);
		System.out.printf("%d ^ 2 = %d", num2, quad2);
		System.out.println();

	}

}
