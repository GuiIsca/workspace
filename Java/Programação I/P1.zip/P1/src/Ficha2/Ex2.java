package Ficha2;

public class Ex2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		byte idadeEmAnos = 23;
		float alturaEmMetros = 1.65f;
		short alturaEmMilimetros = 1650;
		
		short pesoEmKilos = 65;
		double pi =3.1416;
		
		long tamFicheiro=100200110;
		
		boolean portaAberta=false;
		
		float tempCelcius=32.5f;
		float tempFahrenheit=55.4f;
		
		long segundosDesde01011970=198275487;
		byte volume=7;
		
		boolean valorEncontrado=true;
		
	}

}
