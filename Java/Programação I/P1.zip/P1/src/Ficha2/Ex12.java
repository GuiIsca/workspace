package Ficha2;

public class Ex12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		char ch1='h';
		char ch2='Z';
		
		int dif = 'a'-'A';
		
		System.out.println("A diferen�a entre uma min�scula e a mai�scula correspondente �: " + dif);
		
		char maiuscula = (char) (ch1 - dif);
		char minuscula = (char) (ch2 + dif);
		
		System.out.printf("A maiuscula de %c � %c\n", ch1, maiuscula);
		System.out.printf("A minuscula de %c � %c\n", ch2, minuscula);
		

	}

}
