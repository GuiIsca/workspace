package Ficha6;

import java.util.Scanner;

public class Ex14 {
	
	static int devolvePosicao(int[] a, int elem) {
		
		for (int i = 0; i < a.length; i++) {
			if(a[i] == elem)
				return i;
		}

		return -1;
	}

	static boolean existeElemento(int[] a, int elem) {

		return devolvePosicao(a, elem)!=-1;

	}


	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);

		int[] arrayNums = {2, 4, 7, 5, 7, 13, 45, 12, 34};

		System.out.println("Qual o valor que quer procurar?");
		int valor= sc.nextInt();


		System.out.printf("%d %s no array.", valor, existeElemento(arrayNums, valor)? "existe" : "n�o existe");


	}
}
