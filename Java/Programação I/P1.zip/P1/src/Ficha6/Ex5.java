package Ficha6;

import java.util.Scanner;

public class Ex5 {

	static boolean verificarAnoBissexto(int num) {
		if((num % 400 == 0) || ((num % 4 == 0) && (num % 100 != 0))) {
			return true;
		}
		else
			return false;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner (System.in);

		System.out.println("Introduza um n�mero: ");
		int num = sc.nextInt();

		boolean anoBissexto = verificarAnoBissexto(num);

		System.out.println("O ano introduzido � bissexto? "+anoBissexto);

		sc.close();
	}

}
