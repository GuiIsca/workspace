package Ficha6;

import java.util.Scanner;

public class Ex4 {

	static boolean verificarDigito(char letra) {
		if(letra >= 'a' && letra <= 'z' || letra >= 'A' && letra <= 'Z')
			return false;
		else
			return true;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner (System.in);

		System.out.println("Introduza um caracter: ");
		char letra = sc.next().charAt(0);

		boolean verificacao = verificarDigito(letra);
		
		System.out.println("� um digito? "+verificacao);

		sc.close();
	}

}
