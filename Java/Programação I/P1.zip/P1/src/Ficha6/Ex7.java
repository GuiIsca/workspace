package Ficha6;

import java.util.Scanner;

public class Ex7 {
	
	static boolean calcularPrimo(int num) {

		int div=0;
		
		for(int i=1;i<= num;i++) {
		
		if(num % i == 0)
			div++;
		}
		if(div==2) {
			return true;
		}
		else {
			return false; 
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		Scanner sc = new Scanner (System.in);
		
		System.out.println("Introduza um n�mero: ");
		int num= sc.nextInt();
		
	    boolean primo = calcularPrimo(num);
	    
	    System.out.println("O n�mero � primo? "+primo);
	   
		sc.close();

	}

}
