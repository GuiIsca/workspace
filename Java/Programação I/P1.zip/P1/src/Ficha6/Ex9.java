package Ficha6;

import java.util.Scanner;

public class Ex9 {
	
	
	static void leArray( int[] a){
		Scanner sc = new Scanner(System.in);

		for (int i = 0; i < a.length; i++) {
			System.out.printf("introduza um valor [%d]:");
			a[i] =sc.nextInt();
		}
	}

	static void imprimeArray(int[] a, int ini, int fim) {

		for (int i = ini; i<fim; i++) {
			System.out.printf("a[%d] = %d\n", i, a[i]);
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arrayNums = new int[10];

		imprimeArray(arrayNums, 3, 7);

		leArray(arrayNums);

		imprimeArray(arrayNums, 3, 7);

	}

}
