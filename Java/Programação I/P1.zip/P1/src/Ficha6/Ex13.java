package Ficha6;

import java.util.Scanner;

public class Ex13 {

static int devolvePosicao(int[] a, int elem) {
	
	for (int i = 0; i < a.length; i++) {
		if(a[i] == elem)
			return i;
	}

	return -1;
}
	
	
	
public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		int[] arrayNums = {2, 4, 7, 5, 7, 13, 45, 12, 34};
		
		System.out.println("Qual o valor que quer procurar?");
		int valor= sc.nextInt();
		
		int pos = devolvePosicao(arrayNums, valor);
		
		if(pos==-1)
			System.out.println(valor + " n�o foi encontrado no array.");
		else
			System.out.println(valor + " foi encontrado na posi��o " + pos);

	}
}