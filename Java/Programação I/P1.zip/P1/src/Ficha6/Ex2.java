package Ficha6;

import java.util.Scanner;

public class Ex2 {

	static int devolverMaior(int num1, int num2) {

		if(num1 > num2) {
			return num1;
			}
		else if(num2 > num1) {
			return num2;
		}
		return 0;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner (System.in);

		System.out.println("Introduza dois n�meros: ");
		int num1 = sc.nextInt();
		int num2 = sc.nextInt();
		
		int maior = devolverMaior(num1, num2)  ;
		
		System.out.println("O maior n�mero � "+maior);
	}

}
