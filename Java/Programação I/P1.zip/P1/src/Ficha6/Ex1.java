package Ficha6;

import java.util.Scanner;

public class Ex1 {

	static int calculaAbs(int num) {

		return num>0 ? num : -num;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner (System.in);

		System.out.println("Introduza um n�mero: ");
		int num1 = sc.nextInt();

		int abs = calculaAbs(num1);

		System.out.println("|"+num1+"| = "+abs);

		sc.close();

	}

}
