package Ficha6;

import java.util.Scanner;

public class Ex10 {
	
	static void imprimeArray(int[] a, int ini, int fim) {

		for (int i = ini; i<fim; i++) {
			System.out.printf("a[%d] = %d\n", i, a[i]);
		}
	}
	
	static void imprimeArray(int[] a) {
		imprimeArray(a, 0,a.length);
	}

	public static void main(String[] args) {
		
		int[] arrayNums = {10,11,12,13,14,15,16,17,18,19,20};
		
		imprimeArray(arrayNums);

	}

}
