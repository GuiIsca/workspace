package Ficha6;

import java.util.Scanner;

public class Ex8 {
	
	static int calcularExpoente (int base, int exp) {
		int produto=1;

		for (int i=0;i<exp;i++) {

			produto = produto * base;

		}
		return produto;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		Scanner sc = new Scanner (System.in);

		System.out.println("Introduza dois n�meros: ");
		int base = sc.nextInt();
		int exp = sc.nextInt();

		int expoente = calcularExpoente(base,exp);
		
		System.out.println("O produto � "+expoente);
		
		sc.close(); 


	}

}
