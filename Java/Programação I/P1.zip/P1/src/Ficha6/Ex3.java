package Ficha6;

import java.util.Scanner;

public class Ex3 {

	static boolean verificarPar(int num) {
		if(num%2 == 0) {
			return true;
		}
		else
        return false;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner (System.in);

		System.out.println("Introduza um n�mero: ");
		int num = sc.nextInt();
		
		boolean par = verificarPar(num);
		
		System.out.println("O n�mero � par? "+par);
		
		sc.close();
	}

}
