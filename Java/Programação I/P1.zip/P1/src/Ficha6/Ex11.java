package Ficha6;

public class Ex11 {

	static int devolverPosMaior(int[] a) {

		int maior = a[0];
		int iMaior = 0;

		for (int i = 0; i < a.length; i++) {
			if(a[i]>maior) {
				maior = a[i];
				iMaior=i;
			}
		}
		return iMaior;
	}

	public static void main(String[] args) {

		int[] arrayNums = {10,11,12,13,14,15,16,17,18,19,20};

		System.out.println("O maior valor do array est� na posi��o "+devolverPosMaior(arrayNums));

	}

}
