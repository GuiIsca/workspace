package Ficha6;

import java.util.Scanner;

public class Ex6 {

	static long calcularFatorial(int num) {
		long factorial = 1 ;
		
		for(int i = num; i>1 ;i--) {
		factorial = factorial*1;
		}
	 return factorial;
}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner (System.in);

		System.out.println("Introduza um n�mero: ");
		int num = sc.nextInt();

		long fact = calcularFatorial(num);

		System.out.println(num+"! ="+fact);

		sc.close();
	}

}
