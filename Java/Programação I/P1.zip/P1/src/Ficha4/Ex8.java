package Ficha4;

import java.util.Scanner;

public class Ex8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner teclado = new Scanner (System.in);

		System.out.println("Introduza dois n�meros: ");
		int base = teclado.nextInt();
		int exp = teclado.nextInt();

		int produto=1;

		for (int i=0;i<exp;i++) {

			produto = produto * base;

		}

		System.out.println("O produto � "+produto);	

		teclado.close(); 

	}

}
