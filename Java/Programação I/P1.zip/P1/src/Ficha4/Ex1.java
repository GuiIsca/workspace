package Ficha4;

import java.util.Scanner;

public class Ex1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner teclado = new Scanner (System.in);

		System.out.print("Introduza um n�mero inteiro: ");
		int numInt = teclado.nextInt( );
		
		int i=0;
		while( i < numInt ){
			System.out.print( i + "" );
			i++;
		}
		
		System.out.println();
		
		for(int j=0;j<numInt;j++) {
			System.out.println(j);
		}
		
		teclado.close();
	}

}
