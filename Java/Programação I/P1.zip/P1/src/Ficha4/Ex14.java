package Ficha4;

import java.util.Scanner;

public class Ex14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner teclado = new Scanner (System.in);
		
		System.out.println("Introduza o dividendo:");
		int dividendo=teclado.nextInt();
		
		System.out.println("Introduza o divisor:");
		int divisor=teclado.nextInt();
		
		int quociente=0;
		int resto=dividendo;
		
		while(resto>=divisor){
			resto-=divisor;
			quociente++;
		}
		
		System.out.println(dividendo + " / " + divisor + " = " + quociente);
		System.out.println(dividendo + " % " + divisor + " = " + resto);
		
			
		teclado.close();
	}

}
