package Ficha4;

import java.util.Scanner;

public class Ex12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner teclado = new Scanner(System.in);
		
		char ch1='a';
		char ch2='b';	
				
		
		do {
			System.out.println("Introduza dois caracteres:");
			ch1=teclado.next().charAt(0);
			ch2=teclado.next().charAt(0);
			
		   if((ch1>='a' && ch1<='z') && (ch2>='a' && ch2<='z')) {
			   if(ch1 < ch2) {
		
			   for(char ch=ch1;ch<=ch2;ch++) {
				   System.out.println(ch);
			   }
		       } else    
			        for(char ch=ch1;ch>=ch2;ch--) {
							   System.out.println(ch);
			        }
		   }
			else
			    System.out.println("As letras t�m de ser min�sculas!");
			        
			   		
		}while ((ch1 !='.') && (ch2 !='.')) ;
	
		teclado.close();
	
}
	
}

		

	


