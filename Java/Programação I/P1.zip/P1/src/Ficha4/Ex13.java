package Ficha4;

import java.util.Scanner;

public class Ex13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner teclado = new Scanner (System.in);
		
		int num1 = 0;
		int num2 = 0;
		int mult = 0;
		do {	
		   System.out.println("Introduza dois n�meros:");
		   num1 = teclado.nextInt();
		   num2 = teclado.nextInt();
		   
		   for(int i = 0;i<num1;i++) {
			   mult = mult + num2;
			   
		   }
			  System.out.println("A multiplica��o apenas usando soma � "+ mult);
		   } while ((num1 < 0) && (num2 < 0));
				   
		
		teclado.close();
	}

}
