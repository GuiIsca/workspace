package Ficha4;

import java.util.Scanner;

public class Ex9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner teclado = new Scanner (System.in);
		
		System.out.println("Introduza um n�mero: ");
		
		int num= teclado.nextInt();
		
		int fatorial=1;
		
		for(int i=num;i>0; i--) {
			fatorial = fatorial *i;
		}
		
		System.out.println("O fatorial � " +fatorial);
		
		teclado.close();
	}

}
