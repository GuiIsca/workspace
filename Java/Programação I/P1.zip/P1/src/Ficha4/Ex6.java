package Ficha4;

import java.util.Scanner;

public class Ex6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner teclado = new Scanner (System.in);
		
		char ch=0;
		do {
			System.out.println("Introduza um caracter:");
			ch=teclado.next().charAt(0);
			
			if ((ch>='a' && ch<='z') || (ch>='A' && ch<='Z'))
				System.out.println(ch);
			}while(ch !='.');
		
		teclado.close();
	}

}
