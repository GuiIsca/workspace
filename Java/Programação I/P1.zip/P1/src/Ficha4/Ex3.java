package Ficha4;

import java.util.Scanner;

public class Ex3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner teclado = new Scanner (System.in);
		
		System.out.println("Introduza um n�mero inteiro: ");
		int num = teclado.nextInt( );
		
		while(num !=0 ){
			int abs = num > 0 ? num:-num;
			
			System.out.println("|"+num+"|="+abs);
		}	
		teclado.close();
	}

}
