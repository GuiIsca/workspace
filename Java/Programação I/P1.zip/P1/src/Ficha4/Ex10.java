package Ficha4;

import java.util.Scanner;

public class Ex10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	Scanner teclado = new Scanner (System.in);
	
	System.out.println("Introduza um n�mero: ");
	int num= teclado.nextInt();
	
	int div=0;
	
	for(int i=1;i<= num;i++) {
	
	if(num % i == 0)
		div++;
	
	}
    
	if (div ==2) {
		System.out.println("O n�mero � primo");
	}
	else
		System.out.println("O n�mero n�o � primo");
	
	teclado.close();
	}
	
}
