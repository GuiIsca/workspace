package Ficha4;

public class Ex2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	char ch=0;
	for (int cod=0; cod < 256; cod++,ch++) {
		System.out.printf("%03d - %c\n",cod, ch);
	}

	}

}
