package Ficha4;

import java.util.Scanner;

public class Ex7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner teclado = new Scanner (System.in);
		
		System.out.println("Introduza um limite: ");
		int limite = teclado.nextInt();
		
		int soma=0;
		int i=0;
		
		do {
		 i++;
		 soma = soma + i;
		 }while(soma<=limite);
		
		System.out.printf("A soma � igual a %d", soma);
		
		teclado.close();	
		}

	}


