package Ficha4;

import java.util.Scanner;

public class Ex11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner teclado = new Scanner (System.in);
	int num = 0;	
	do {	
	   System.out.println("Introduza um numero:");
	   num = teclado.nextInt();
	   
	   for(int i=0 ; i <num; i++) {
		   System.out.printf("*");
	   }
		  
	   } while(num!= 0);
	
	teclado.close();
	}

}
