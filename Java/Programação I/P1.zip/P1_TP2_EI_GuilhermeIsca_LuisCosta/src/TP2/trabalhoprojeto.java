package TP2;

import java.util.Scanner;

public class trabalhoprojeto {
	
	
	static void apresentaMenuPrincipal(int nLivros,int i,int [] paginasLidas, int [] paginas,boolean [] emprestado,String [] autor,String []titulo){
		char opcao1;
		do {
			System.out.println("(V)isualizar\n(E)ditar\n(L)er\n(S)air");
			opcao1 = lerOpcao();
			switch(opcao1){
			case 'V':
				apresentaMenuVisualizar(nLivros,i,paginasLidas,paginas,emprestado,autor,titulo);
				break;
			case 'E':
				apresentaMenuEditar(i,nLivros,titulo,autor,paginas);	
				break;
			case 'L':
				apresentaMenuLer(i,nLivros,titulo,autor,paginas,paginasLidas,emprestado);
				break;
			default: 
				System.out.println("Opc�o Inv�lida!!");	
			}
			
		}while(opcao1!='S');
		
		}
	
	static void apresentaMenuVisualizar(int nLivros,int i,int [] paginasLidas, int [] paginas,boolean [] emprestado,String [] autor,String []titulo) {
		char opcaoVisualizar;
		do {
			System.out.println("\nVisualizar (t)odos os livros\nVisualizar livros em (l)eitura\nVisualizar livros te(r)minados\nVisualizar livros (p)or ler\nVisualizar livros (e)mprestados\n(V)oltar");
			opcaoVisualizar = lerOpcaoVisualizar();
			switch (opcaoVisualizar) {
			case 't':
				apresentaTodosOsLivros(nLivros,i,paginasLidas,paginas,emprestado,autor,titulo);
				break;
			case 'l':
				apresentaLivrosLeitura(i,nLivros,titulo,paginasLidas,paginas);
				break;
			case 'r':
				apresentaLivrosTerminados(i,nLivros,paginasLidas,paginas,titulo);
				break;
			case 'p':
				apresentaLivrosPorLer (i,nLivros,paginasLidas,titulo);
				break;
			case 'e':
				 apresentaEmprestados(i,nLivros,titulo,emprestado);
				break;
			case 'V':
				break;
			default: 
				System.out.println("Opc�o Inv�lida!!");				
				
			}
			
		}while(opcaoVisualizar!='V');
		
	}
	
	static void apresentaMenuEditar(int i,int nLivros,String []titulo,String []autor,int []paginas) {
		char opcaoEditar;
		System.out.println("Adicionar (l)ivro\nProcurar livro por (t)itulo\nProcurar livro por (a)utor\nApagar livro por (p)osi��o\nApagar to(d)os os livros de um autor\n(E)ditar livro\n(V)oltar");
		opcaoEditar = lerOpcaoEditar();
		switch (opcaoEditar) {
		case 'l':
			break;
		case 't':
			procuraLivroPTitulo(i,nLivros,titulo);
			break;
		case 'a':
			procuraPorAutor(i,nLivros,autor,titulo);
			break;
		case 'p':
			break;
		case 'd':
			break;
		case 'E':
			apresentaEditarLivro(nLivros,i,titulo,autor,paginas);
			break;
		case 'V':
			break;
		default: 
			System.out.println("Opc�o Inv�lida!!");	
		
		}
		
		
	}
	
	static void apresentaMenuLer(int i,int nLivros,String[]titulo,String[]autor,int []paginas, int []paginasLidas,boolean []emprestado) {
		char opcaoLer;
		System.out.println("Procurar livros por (t)�tulo\nProcurar livro por (a)utor\n(M)arcar como lido\nAlterar (p)�ginas lidas\n(E)mprestar livro\nMostrar (n)�mero de livros lidos\nMostrar n�mero de p�ginas (l)idas\n(V)oltar");
		opcaoLer = lerOpcaoLer();
		switch(opcaoLer) {
		case 't':
			procuraLivroPTitulo(i,nLivros,titulo);
			break;
		case 'a':
			procuraPorAutor(i,nLivros,autor,titulo);
			break;
		case 'M':
			marcarLido(nLivros,i,paginas,paginasLidas);
			break;
		case 'p':
			alterarPagLidas(nLivros,i,paginasLidas);
			break;
		case 'E':
			emprestaLivro(nLivros,i,emprestado);
			break;
		case 'n':
			mostraNumLivrosLidos(nLivros,i,paginasLidas,paginas);			
			break;
		case 'l':
			mostraNumPagLidas (nLivros,i,paginasLidas);
			break;
		case 'V':
			break;
		default: 
			System.out.println("Opc�o Inv�lida!!");
		}
	}
	static void apresentaEditarLivro(int nLivros,int i,String []titulo,String []autor,int []paginas) {
		char opcaoEditarLivro;
		System.out.println("Alterar (t)�tulo\nAlterar (a)utor\nAlterar (n)�mero de p�ginas\n(V)oltar");
		opcaoEditarLivro=lerOpcaoEditarLivro();
		switch (opcaoEditarLivro)
		{
		case 't':
			alterarTitulo(nLivros,i,titulo);
			break;
		case 'a':
			alterarAutor(nLivros,i,autor);
			break;
		case 'n':
			alterarNumPaginas( nLivros,i,paginas);
			break;
		case 'V':
			break;
		default: 
			System.out.println("Opc�o Inv�lida!!");
		}
		
	}
	
	
	
////////////////////////////////////////////////////////////M�todos para menu visualizar/////////////////////////////////////////////////////
	
	static void apresentaTodosOsLivros(int nLivros,int i,int [] paginasLidas, int [] paginas,boolean [] emprestado,String [] autor,String []titulo) {
		System.out.printf("%-30s %8s %30s %6s %7s","   T�tulo", "Autor", "P�ginas", "Pag.Lidas", "Emprestado");
		for( i=0;i<nLivros;i++)
		{
			
			
			System.out.printf("\n%d: %-30s %-25s %9s %10s %10s",i+1,titulo[i],autor[i],paginas[i],paginasLidas[i],emprestado[i]);			
		}
		System.out.println();
	}
	
	static void apresentaLivrosLeitura(int i,int nLivros,String[]titulo,int [] paginasLidas,int []paginas) {
		for ( i = 0;i<nLivros;i++)
		{
			if(paginasLidas[i]>0 && paginasLidas[i]<paginas[i])
			{
				System.out.println(titulo[i]);
			}
				
		}
	}
	
	static void apresentaLivrosTerminados(int i,int nLivros,int []paginasLidas,int []paginas,String []titulo) {
		for ( i = 0;i<nLivros;i++)
		{
			if(paginasLidas[i]==paginas[i])
			{
				System.out.println(titulo[i]);
			}
				
		}
	}
	
	static void apresentaLivrosPorLer (int i,int nLivros,int []paginasLidas,String []titulo) {
		for ( i = 0;i<nLivros;i++)
		{
			if(paginasLidas[i]==0)
			{
				System.out.println(titulo[i]);
			}
				
		}
	}
	
	static void apresentaEmprestados(int i,int nLivros,String []titulo,boolean [] emprestado) {
		for (i = 0;i<nLivros;i++)
		{
			if(emprestado[i]==true)
			{
				System.out.println(titulo[i]);
			}
				
		}
	}
	
	/////////////////////////////////////////////////////////////////M�todos menu editar/////////////////////////////////////////////////
	static void procuraLivroPTitulo(int i,int nLivros,String []titulo) {
		System.out.println("Introduza um t�tulo: ");
		String tituloProc=lerTitulo();
		for(i=0;i<nLivros;i++)
		{
			titulo[i].indexOf(tituloProc);
			if(titulo[i].indexOf(tituloProc)==0)
				System.out.println(titulo[i]);
		}
	}
	
	static void procuraPorAutor(int i,int nLivros,String []autor,String []titulo) {
		System.out.println("Introduza o autor a procurar: ");
		String autorProc = lerAutor();
		for(i=0;i<nLivros;i++)
		{
			autor[i].indexOf(autorProc);
			if(autor[i].indexOf(autorProc)==0)
			{
				System.out.println(titulo[i]);
				
			}
		}
	}
	
	static void alterarTitulo(int nLivros,int i,String []titulo) {
		System.out.println("Introduza a posi��o onde o livro se encontra: ");
		int posLivro=posicaoLivro();
		System.out.println("Novo t�tulo do livro: ");
		String tituloAtual=novoTitulo();
		for(i=0;i<nLivros;i++)
		{
			if(posLivro==i)
				titulo[i]=tituloAtual;
		}
	}
	
	static void alterarAutor(int nLivros,int i,String []autor) {
		System.out.println("Introduza a posi��o onde o livro se encontra: ");
		int posLivro=posicaoLivro();
		System.out.println("Nome do autor: ");
		String autorAtual=novoAutor();
		for(i=0;i<nLivros;i++)
		{
			if(posLivro==i)
				autor[i]=autorAtual;
		}
	}
	
	static void alterarNumPaginas(int nLivros,int i,int []paginas) {
		System.out.println("Introduza a posi��o onde o livro se encontra: ");
		int posLivro=posicaoLivro();
		System.out.println("Quantas p�ginas quer que o livro tenha: ");
		int paginasAtual=AtualizaNumPag();
		for(i=0;i<nLivros;i++)
		{
			if(posLivro==i)
				paginas[i]=paginasAtual;
		}
	}

/////////////////////////////////////////////////////////////////M�todos para Menu LER //////////////////////////////////////////////////////	
	
	static void marcarLido(int nLivros,int i,int []paginas,int []paginasLidas) {
		int procLido;
		System.out.println("Introduza a posi��o do livro que quer marcar como lido: ");
		procLido= posicaoLivro();
		for(i=0;i<nLivros;i++)
		{
			if(procLido==i)
			{
				paginasLidas[i]=paginas[i];
				
			}
				
		}
	}
	
	static void alterarPagLidas(int nLivros,int i,int []paginasLidas) {
		int pagLidasAtual;
		System.out.println("Introduza a posi��o em que o livro se encontra: ");
		int posLivro=posicaoLivro();
		System.out.println("Quantas p�ginas leu? ");
		pagLidasAtual=pagLidasAtual();
		for(i=0;i<nLivros;i++)
		{
			if(posLivro==i)
			{
				paginasLidas[i]=pagLidasAtual;
			}
		}
	}
	
	static void emprestaLivro(int nLivros,int i,boolean []emprestado) {
		System.out.println("Vai marcar como EMPRESTADO!!\nIntroduza a posi��o em que o livro se encontra: ");
		int posLivro=posicaoLivro();
		for(i=0;i<nLivros;i++)
		{
			if(posLivro==i)
			{
				emprestado[i]=true;
			}
		}
	}
	
	static void mostraNumLivrosLidos(int nLivros,int i,int []paginasLidas,int []paginas) {
		int lidos=0;
		for(i=0;i<nLivros;i++)
		{
			if(paginasLidas[i]==paginas[i])
			{
				lidos=i+1;
			}
		}
		System.out.printf("O n�mero de livros lidos � igual a %d\n\n",lidos);
		
	}
	
	
	static void mostraNumPagLidas (int nLivros,int i,int []paginasLidas) {
		int pagLidasTotal=0;
		for(i=0;i<nLivros;i++)
		{
			pagLidasTotal=pagLidasTotal+paginasLidas[i];
		}
		System.out.printf("O n�mero de p�ginas lidas no total vai ser %d\n\n",pagLidasTotal);
	}
	
	
	
	

	
	
/////////////////////////////////////////////////////////////////M�todos para ler (return)/////////////////////////////////////////////
	
	static int pagLidasAtual() {
		Scanner teclado = new Scanner(System.in);
		int pagLidasAtual=teclado.nextInt();
		teclado.nextLine();
		return pagLidasAtual;
	}
	
	static int AtualizaNumPag() {
		Scanner teclado = new Scanner(System.in);
		int paginasAtual=teclado.nextInt();
		teclado.nextLine();
		return paginasAtual;
	}
	static String novoAutor() {
		Scanner teclado = new Scanner(System.in);
		String autorAtual = teclado.next();
		teclado.nextLine();
		return autorAtual;
	}
	static String novoTitulo() {
		Scanner teclado = new Scanner(System.in);
		String tituloAtual = teclado.next();
		teclado.nextLine();
		return tituloAtual;
	}
	static int posicaoLivro() {
		int posLivro;
		Scanner teclado = new Scanner(System.in);
		posLivro = teclado.nextInt();
		teclado.nextLine();
		return posLivro;
	}
	static String lerAutor() {
		Scanner teclado = new Scanner(System.in);
		String autorProc = teclado.next();
		teclado.nextLine();
		return autorProc;
	}
	
	
	static String lerTitulo() {
		Scanner teclado = new Scanner(System.in);
		String tituloProc = teclado.next();	
		teclado.nextLine();
		return tituloProc;
		
	}
	
	
	static char lerOpcao() {
		char opcao1;
		Scanner teclado = new Scanner(System.in);
		opcao1 = teclado.next().charAt(0);	
		teclado.nextLine();
		return opcao1;
		
	}
	
	static char lerOpcaoVisualizar() {
		char opcaoVisualizar;
		Scanner teclado = new Scanner(System.in);
		opcaoVisualizar = teclado.next().charAt(0);
		teclado.nextLine();
		return opcaoVisualizar;
		
	}
	static char lerOpcaoEditar() {
		char opcaoEditar;
		Scanner teclado = new Scanner(System.in);
		opcaoEditar = teclado.next().charAt(0);
		teclado.nextLine();		
		return opcaoEditar;
		
	}
	static char lerOpcaoLer() {
		char opcaoLer;
		Scanner teclado = new Scanner(System.in);
		opcaoLer = teclado.next().charAt(0);
		teclado.nextLine();
		return opcaoLer;
		
	}

	static char lerOpcaoEditarLivro() {
		char opcaoEditarLivro;
		Scanner teclado = new Scanner(System.in);
		opcaoEditarLivro = teclado.next().charAt(0);
		teclado.nextLine();
		return opcaoEditarLivro;
		
	}

	public static void main(String[] args) {
		//Lu�s Filipe Gaspar Costa n�20211718 INF3-Engenharia Inform�tica
		//Guilherme Isca n�20210775 INF3-Engenharia Inform�tica
					
				int tamMax=100;
				String [] titulo = new String[tamMax];
				String [] autor = new String[tamMax];
				int [] paginas = new int[tamMax];
				int [] paginasLidas = new int[tamMax];
				boolean [] emprestado = new boolean[tamMax];
				int nLivros=0,i=0;
				
				
				titulo[0] = "In�s de Castro";
				autor[0] = "Isabel Stilwell";
				paginas[0] = 488;
				paginasLidas[0] = 488;
				emprestado[0] = false;
				titulo[1] = "Ast�rix e a Transit�lica";
				autor[1] = "Jean-Yves Ferri";
				paginas[1] = 46;
				paginasLidas[1] = 46;
				emprestado[1] = false;
				titulo[2] = "Ast�rix e o Grifo";
				autor[2] = "Jean-Yves Ferri";
				paginas[2] = 48;
				paginasLidas[2] = 12;
				emprestado[2] = false;
				titulo[3] = "O Jardim dos Animais com Alma";
				autor[3] = "Jos� Rodrigues dos Santos";
				paginas[3] = 504;
				paginasLidas[3] = 0;
				emprestado[3] = true;
				titulo[4] = "�ltimo Olhar";
				autor[4] = "Miguel Sousa Tavares";
				paginas[4] = 504;
				paginasLidas[4] = 0;
				emprestado[4] = true;
				nLivros=5;
				
				
			apresentaMenuPrincipal(nLivros,i,paginasLidas,paginas,emprestado,autor,titulo);
				
			
			}	

	}



