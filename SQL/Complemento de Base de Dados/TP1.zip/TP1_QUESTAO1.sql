//JO�O PEDRO DIAS N�20211714 
//GUILHERME ISCA N�20210775

/*1)
a) Crie um procedimento (ListarExposicoesComObras) em PLSQL que, para uma das EXPOSI��ES existentes liste:
- todos os respetivos dados;
- e para cada uma liste todas as informa��es sobre a obras nela expostas.*/
SET SERVEROUTPUT ON
SHOW SERVEROUTPUT

CREATE OR REPLACE PROCEDURE ListarExposicoesComObras IS


  CURSOR exposicao_cursor IS
    SELECT * FROM Exposicao;

  CURSOR obra_cursor(p_exposicao_id exposicaoobraarte.id_obra%TYPE ) IS
    SELECT eo.id_obra,
                   oa.titulo,
                   oa.ano_criacao,
                   eo.preco
    FROM exposicaoobraarte eo
    INNER JOIN obradearte oa ON eo.id_obra = oa.id_obra
    WHERE eo.id_exposicao = p_exposicao_id;

  v_exposicao Exposicao%ROWTYPE;



BEGIN
  FOR v_exposicao IN exposicao_cursor LOOP
    DBMS_OUTPUT.PUT_LINE('Exposi��o n� ' || v_exposicao.id_exposicao ||
                         ' -- Nome: ' || v_exposicao.nome_exposicao ||
                         ' -- Data In�cio: ''' || TO_CHAR(v_exposicao.DataInicio, 'YYYY.MM.DD') || ''' ' ||
                         '� Data Fim: ''' || TO_CHAR(v_exposicao.DataFim, 'YYYY.MM.DD') || ''' ' ||
                         ' -- Total_Exposto: ' || v_exposicao.valortotalexposicao);

    FOR v_obra IN obra_cursor(v_exposicao.id_exposicao) LOOP
      DBMS_OUTPUT.PUT_LINE(' ObraID: ' ||v_obra.id_obra||
                           ' -- Titulo: ''' ||v_obra.titulo || ''' ' ||
                           '� Data Cria��o: ''' || v_obra.ano_criacao || ''' ' ||
                           ' -- Pre�o: ' || v_obra.preco);
    END LOOP;

    DBMS_OUTPUT.NEW_LINE;
  END LOOP;
END;
--------------- ------------------------------------TESTAR PROCEDIMENTO-----------------------------------
EXECUTE ListarExposicoesComObras();




-----------------------------------------------------------------------------------------------------------------------------------------
/*b) Suponha que � pretendido classificar as exposi��es com base no seu valor total exposto. Assim:
- se o valor total exposto for de pelo menos 300, a classifica��o dever� ser 'Platina';
- se o valor total exposto for de pelo menos 250 e menos do que 300, a classifica��o dever� ser 'Ouro';
- se o valor total exposto for de pelo menos 200 e menos do que 250, a classifica��o dever� ser 'Prata';
- se o valor total exposto for de pelo menos 100 e menos o que 200, a classifica��o dever� ser 'Bronze';
- nos restantes casos dever� ser 'Sem classfica��o'.
Para tal construa uma fun��o (ClassificaExposicao) que receba como par�metro de entrada o identificador de uma dada
exposi��o, e que retorne a respetiva classifica��o.*/


CREATE OR REPLACE FUNCTION ClassificaExposicao(vp_id_exposicao exposicao.id_exposicao%TYPE)
RETURN VARCHAR2

IS

classificacao varchar2(20);
v_valorTotal Exposicao.ValorTotalExposicao%TYPE;

BEGIN 

SELECT ValorTotalExposicao 
INTO v_valorTotal
FROM Exposicao
WHERE id_exposicao = vp_id_exposicao;

IF v_valorTotal >= 100 AND v_valorTotal <200 THEN
    classificacao := 'Bronze';

ELSIF v_valorTotal >= 200 AND v_valorTotal <250 THEN
    classificacao := 'Prata';
    
ELSIF v_valorTotal >= 250 AND v_valorTotal <300 THEN
    classificacao := 'Ouro';
    
ELSIF v_valorTotal >= 300 THEN
    classificacao := 'Platina';


ELSE
    classificacao := 'Sem Classifica��o';

END IF;

RETURN(classificacao);

END;

----------------------------------------------TESTAR FUN��O-----------------------------------
DECLARE
    
v_classificacao varchar2(20);

BEGIN
   v_classificacao := ClassificaExposicao(1);
  
   dbms_output.put_line(v_classificacao);
  
END;

