//JO�O PEDRO DIAS N�20211714 
//GUILHERME ISCA N�20210775

/*2)
a) Crie um trigger, em PLSQL, que para cada nova inser��o na tabela 'Exposicao_Obra' atualize o atributo
'ValorTotalExposicao' na tabela 'Exposicao', somando o novo 'preco' ao valor atual. Crie tamb�m as variantes para os
casos em que em vez da inser��o a a��o na tabela 'Exposicao_Obra' seja um UPDATE ou um DELETE.
*/

CREATE OR REPLACE TRIGGER atualiza_valor
AFTER INSERT OR UPDATE OR DELETE ON ExposicaoObraArte
FOR EACH ROW

DECLARE 
v_total ExposicaoObraArte.preco%TYPE;

BEGIN
 
IF INSERTING THEN
    SELECT ValorTotalExposicao
    INTO v_total
    FROM Exposicao
    WHERE id_exposicao = :new.id_exposicao;
    
    UPDATE exposicao
    SET ValorTotalExposicao = v_total + :NEW.preco
    WHERE id_exposicao = :new.id_exposicao;
    
ELSIF UPDATING THEN
    SELECT ValorTotalExposicao
    INTO v_total
    FROM Exposicao
    WHERE id_exposicao = :new.id_exposicao;
    
    IF :new.preco < 0 THEN
        RAISE_APPLICATION_ERROR(-20001, 'O novo pre�o n�o pode ser menor que zero.');
    END IF;
    
    UPDATE exposicao
    SET ValorTotalExposicao =(v_total - :OLD.preco ) + :new.preco
    WHERE id_exposicao = :new.id_exposicao;

ELSIF DELETING THEN
    SELECT ValorTotalExposicao
    INTO v_total
    FROM Exposicao
    WHERE id_exposicao = :OLD.id_exposicao;
    
    UPDATE exposicao
    SET ValorTotalExposicao = v_total - :OLD.preco
    WHERE id_exposicao = :OLD.id_exposicao;
END IF;
END;



/*b) Considere uma tabela ObraMaisValiosaExposicao que dever� conter a informa��o sobre a obra
com o maior pre�o de cada exposi��o ('Identificador da Exposi��o'; 'Identificador Obra'; e 'Pre�o�).
Crie um trigger que por cada nova inser��o na tabela 'Exposicao_Obra' verifique
se essa obra � a que tem o maior pre�o nessa exposi��o, se for deve atualizar a informa��o na tabela
ObraMaisValiosaExposicao (tenha em considera��o eventuais exce��es, como os casos que em numa mesma exposi��o
possam existir v�rias obras com o mesmo valor m�ximo, sendo que nestes casos todas essas obras dever�o constar na
tabela 'ObraMaisValiosaExposicao�).*/

---- A CRIA��O DA TABELA ESTA NO FICHEIRO DE CRIA��O DE TABELAS!---
    
CREATE OR REPLACE TRIGGER Atualiza_ObraValiosa
AFTER INSERT ON ExposicaoObraArte
FOR EACH ROW

DECLARE
PRAGMA AUTONOMOUS_TRANSACTION;
    

v_id_obra  exposicaoobraarte.id_obra%TYPE;
v_Id_exposicao ExposicaoObraArte.id_exposicao%TYPE;
v_preco ExposicaoObraArte.preco%TYPE;
v_max_preco ExposicaoObraArte.preco%TYPE;
  
  CURSOR c_obra IS
                                SELECT id_exposicao,id_obra, preco 
                                FROM ExposicaoObraArte 
                                WHERE id_exposicao = :new.id_exposicao
                                ORDER BY preco DESC;

BEGIN

  OPEN c_obra;

  FETCH c_obra INTO v_id_exposicao,v_id_obra,v_preco;
  
  INSERT INTO ObraMaisValiosa (id_exposicao, id_obra, preco) VALUES (v_id_exposicao,v_id_obra,v_preco);
  v_max_preco:= v_preco;
  
FETCH c_obra INTO v_id_exposicao,v_id_obra,v_preco;
  
  WHILE c_obra%FOUND LOOP
  
    IF v_preco = v_max_preco THEN
      INSERT INTO ObraMaisValiosa (id_exposicao, id_obra, preco) VALUES (v_id_exposicao,v_id_obra,v_preco);
    END IF;
    
   FETCH c_obra INTO v_id_exposicao,v_id_obra,v_preco;

  END LOOP;

  CLOSE c_obra;
    
COMMIT;
END;




DROP TRIGGER atualiza_valor;

DELETE FROM EXPOSICAOOBRAARTE;
DELETE FROM ObraMaisValiosa;

insert into exposicaoobraarte (id_exposicao,id_obra,preco)values (1,1,200);

select * from exposicao;
select * from exposicaoobraarte;