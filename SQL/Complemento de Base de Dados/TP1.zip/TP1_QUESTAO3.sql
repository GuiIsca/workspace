//JO�O PEDRO DIAS N�20211714 
//GUILHERME ISCA N�20210775
/*3 a) Crie um procedimento, ou uma fun��o ou um pacote da autoria do grupo

Esta fun��o recebe o ID de uma obra de arte como par�metro de entrada e 
retorna o n�mero de exposi��es em que essa obra de arte est� presente.*/

CREATE OR REPLACE FUNCTION contarExposicoesObraArte(
vf_id_obra IN ObraDeArte.id_obra%TYPE
)
RETURN NUMBER
IS
    qtd_exposicoes NUMBER;
           
BEGIN
    
    SELECT COUNT(id_exposicao)
    INTO qtd_exposicoes
    FROM ExposicaoObraArte 
    WHERE vf_id_obra = id_obra;
    
    IF qtd_exposicoes = 0 THEN
        DBMS_OUTPUT.PUT_LINE('A obra de arte com o ID ' || vf_id_obra || ' n�o foi encontrada ou n�o tem exposi��es.');
        RETURN 0;
    END IF;
    
    RETURN qtd_exposicoes ;
    
END;

----------------------------------------------TESTAR FUN��O-----------------------------------
set serveroutput on;
DECLARE 
    v_res NUMBER;
BEGIN
     v_res := contarExposicoesObraArte(2);
   
    IF v_res >= 1 THEN
     DBMS_OUTPUT.PUT_LINE('N� de exposi��es: ' || v_res);
     
    END IF;
END;     


/*b) Crie um trigger de autoria do grupo.

Trigger para impedir exposi��es sobrepostas
*/
CREATE OR REPLACE TRIGGER impedirExposicoesSobrepostas
BEFORE INSERT OR UPDATE ON Exposicao
FOR EACH ROW
DECLARE
    v_qtd_sobrepostas NUMBER;
BEGIN

    SELECT COUNT(*)
    INTO v_qtd_sobrepostas
    FROM Exposicao
    WHERE (:new.DataInicio BETWEEN DataInicio AND DataFim OR
           :new.DataFim BETWEEN DataInicio AND DataFim OR
           DataInicio BETWEEN :new.DataInicio AND :new.DataFim OR
           DataFim BETWEEN :new.DataInicio AND :new.DataFim);

    IF v_qtd_sobrepostas > 0 THEN
        RAISE_APPLICATION_ERROR(-20006, 'A nova exposi��o tem datas sobrepostas com outra exposi��o existente.');
        
    END IF;
END;

----------------------------------------------TESTAR TRIGGER-----------------------------------

DELETE FROM Exposicao;

INSERT INTO Exposicao (id_exposicao, nome_exposicao, DataInicio, DataFim, ValorTotalExposicao) VALUES (1, 'Exposi��o 1', '2023-11-01', '2023-11-30', 200);
INSERT INTO Exposicao (id_exposicao, nome_exposicao, DataInicio, DataFim, ValorTotalExposicao) VALUES (2, 'Exposi��o 2', '2023-10-15', '2023-12-15', 0);


DROP TRIGGER impedirExposicoesSobrepostas;
