//JO�O PEDRO DIAS N�20211714 
//GUILHERME ISCA N�20210775

---------------------------------------CRIA��O DE TABELAS----------------------------------------

CREATE TABLE ObraDeArte (
    id_obra INT PRIMARY KEY,
    titulo VARCHAR2(50),
    ano_criacao INT
);

CREATE TABLE Exposicao (
    id_exposicao INT PRIMARY KEY,
    nome_exposicao VARCHAR2(100),
    DataInicio DATE,
    DataFim DATE,
    ValorTotalExposicao DECIMAL(10, 2)
);

CREATE TABLE ExposicaoObraArte (
    id_exposicao INT,
    id_obra INT,
    preco DECIMAL(10, 2),
    PRIMARY KEY (id_exposicao, id_obra)
);

---CONSTRAINT PARA QUE O PRE�O SEJA POSITIVO
ALTER TABLE ExposicaoObraArte
ADD CONSTRAINT chk_preco_maior_que_zero CHECK (preco > 0);

--  FOREIGN KEY para id_exposicao
ALTER TABLE ExposicaoObraArte
ADD CONSTRAINT fk_exposicao_id
FOREIGN KEY (id_exposicao) REFERENCES Exposicao(id_exposicao);

--  FOREIGN KEY para id_obra
ALTER TABLE ExposicaoObraArte
ADD CONSTRAINT fk_obra_id
FOREIGN KEY (id_obra) REFERENCES ObraDeArte(id_obra);


---------------------------------------INSERTS TABELAS----------------------------------------
INSERT INTO ObraDeArte (id_obra, titulo, ano_criacao) VALUES (1, 'A Cria��o de Ad�o', 1512);
INSERT INTO ObraDeArte (id_obra, titulo, ano_criacao) VALUES (2, 'Nascimento de V�nus', 1484);
INSERT INTO ObraDeArte (id_obra, titulo, ano_criacao) VALUES (3, 'O Beijo', 1907);
INSERT INTO ObraDeArte (id_obra, titulo, ano_criacao) VALUES (4, 'O Pintor e seu Modelo', 1963);
INSERT INTO ObraDeArte (id_obra, titulo, ano_criacao) VALUES (5, 'Mulher com Chap�u', 1901);
INSERT INTO ObraDeArte (id_obra, titulo, ano_criacao) VALUES (6, 'Retrato de Dora Maar', 1937);
INSERT INTO ObraDeArte (id_obra, titulo, ano_criacao) VALUES (7, 'O Jardim das Del�cias Terrenas', 1490);
INSERT INTO ObraDeArte (id_obra, titulo, ano_criacao) VALUES (8, 'O Nascimento de V�nus', 1879);
INSERT INTO ObraDeArte (id_obra, titulo, ano_criacao) VALUES (9, 'A Liberdade Guiando o Povo', 1830);
INSERT INTO ObraDeArte (id_obra, titulo, ano_criacao) VALUES (10, 'Campo de Trigo com Corvos', 1890);

INSERT INTO Exposicao (id_exposicao, nome_exposicao, DataInicio, DataFim, ValorTotalExposicao) VALUES (1, 'Exposi��o 1', '2023-11-01', '2023-11-30', 0);
INSERT INTO Exposicao (id_exposicao, nome_exposicao, DataInicio, DataFim, ValorTotalExposicao) VALUES (2, 'Exposi��o 2', '2023-12-01', '2023-12-31', 0);
INSERT INTO Exposicao (id_exposicao, nome_exposicao, DataInicio, DataFim, ValorTotalExposicao) VALUES (3, 'Exposi��o 3', '2024-01-01', '2024-01-31', 0);
INSERT INTO Exposicao (id_exposicao, nome_exposicao, DataInicio, DataFim, ValorTotalExposicao) VALUES (4, 'Exposi��o 4', '2024-02-01', '2024-02-29', 0);
INSERT INTO Exposicao (id_exposicao, nome_exposicao, DataInicio, DataFim, ValorTotalExposicao) VALUES (5, 'Exposi��o 5', '2024-03-01', '2024-03-31', 0);
INSERT INTO Exposicao (id_exposicao, nome_exposicao, DataInicio, DataFim, ValorTotalExposicao) VALUES (6, 'Exposi��o 6', '2024-04-01', '2024-04-30', 0);
INSERT INTO Exposicao (id_exposicao, nome_exposicao, DataInicio, DataFim, ValorTotalExposicao) VALUES (7, 'Exposi��o 7', '2024-05-01', '2024-05-31', 0);
INSERT INTO Exposicao (id_exposicao, nome_exposicao, DataInicio, DataFim, ValorTotalExposicao) VALUES (8, 'Exposi��o 8', '2024-06-01', '2024-06-30', 0);
INSERT INTO Exposicao (id_exposicao, nome_exposicao, DataInicio, DataFim, ValorTotalExposicao) VALUES (9, 'Exposi��o 9', '2024-07-01', '2024-07-31', 0);
INSERT INTO Exposicao (id_exposicao, nome_exposicao, DataInicio, DataFim, ValorTotalExposicao) VALUES (10,'Exposi��o 10', '2024-08-01', '2024-08-31', 0);
INSERT INTO Exposicao (id_exposicao, nome_exposicao, DataInicio, DataFim, ValorTotalExposicao) VALUES (11,'Exposi��o 11', '2024-08-01', '2024-08-31', 0);




INSERT INTO ExposicaoObraArte (id_exposicao, id_obra, preco) VALUES (1, 1, 50000);
INSERT INTO ExposicaoObraArte (id_exposicao, id_obra, preco) VALUES (1, 3, 50000);
INSERT INTO ExposicaoObraArte (id_exposicao, id_obra, preco) VALUES (1, 5, 20000);
INSERT INTO ExposicaoObraArte (id_exposicao, id_obra, preco) VALUES (2, 2, 60000);
INSERT INTO ExposicaoObraArte (id_exposicao, id_obra, preco) VALUES (2, 4, 80000);
INSERT INTO ExposicaoObraArte (id_exposicao, id_obra, preco) VALUES (3, 6, 50000);
INSERT INTO ExposicaoObraArte (id_exposicao, id_obra, preco) VALUES (3, 7, 40000);
INSERT INTO ExposicaoObraArte (id_exposicao, id_obra, preco) VALUES (4, 8, 90000);
INSERT INTO ExposicaoObraArte (id_exposicao, id_obra, preco) VALUES (4, 9, 70000);
INSERT INTO ExposicaoObraArte (id_exposicao, id_obra, preco) VALUES (4, 10, 10000);
INSERT INTO ExposicaoObraArte (id_exposicao, id_obra, preco) VALUES (5, 1, 50000);
INSERT INTO ExposicaoObraArte (id_exposicao, id_obra, preco) VALUES (5, 5, 20000);
INSERT INTO ExposicaoObraArte (id_exposicao, id_obra, preco) VALUES (5, 6, 50000);
INSERT INTO ExposicaoObraArte (id_exposicao, id_obra, preco) VALUES (6, 1, 50000);
INSERT INTO ExposicaoObraArte (id_exposicao, id_obra, preco) VALUES (6, 3, 30000);
INSERT INTO ExposicaoObraArte (id_exposicao, id_obra, preco) VALUES (6, 5, 20000);
INSERT INTO ExposicaoObraArte (id_exposicao, id_obra, preco) VALUES (7, 2, 60000);
INSERT INTO ExposicaoObraArte (id_exposicao, id_obra, preco) VALUES (7, 4, 80000);
INSERT INTO ExposicaoObraArte (id_exposicao, id_obra, preco) VALUES (8, 6, 50000);
INSERT INTO ExposicaoObraArte (id_exposicao, id_obra, preco) VALUES (8, 7, 40000);
INSERT INTO ExposicaoObraArte (id_exposicao, id_obra, preco) VALUES (9, 8, 90000);
INSERT INTO ExposicaoObraArte (id_exposicao, id_obra, preco) VALUES (9, 9, 70000);
INSERT INTO ExposicaoObraArte (id_exposicao, id_obra, preco) VALUES (10, 10, 10000);
INSERT INTO ExposicaoObraArte (id_exposicao, id_obra, preco) VALUES (10, 7, 40000);
INSERT INTO ExposicaoObraArte (id_exposicao, id_obra, preco) VALUES (11, 1, 50000);
INSERT INTO ExposicaoObraArte (id_exposicao, id_obra, preco) VALUES (1, 2, 50000);

----------------------------------ADICIONAR O VALOR TOTAL NA TABELA EXPOSI��O--------------------
UPDATE Exposicao
SET ValorTotalExposicao = (
    SELECT SUM(preco)
    FROM ExposicaoObraArte
    WHERE ExposicaoObraArte.id_exposicao = Exposicao.id_exposicao
);



-----------------------------------------------------DROPS--------------------------------------------------------------

ALTER TABLE ExposicaoObraArte
DROP CONSTRAINT fk_exposicao_id;

ALTER TABLE ExposicaoObraArte
DROP CONSTRAINT fk_obra_id;

DROP TABLE ExposicaoObraArte;
DROP TABLE ObraDeArte;
DROP TABLE Exposicao;

------------------------------------------------------- TABELA EXERCICIO 2B-----------------------
CREATE TABLE ObraMaisValiosa(
    id_exposicao INT,
    id_obra INT,
    preco DECIMAL(10, 2),
    PRIMARY KEY (id_exposicao, id_obra));
    
ALTER TABLE ObraMaisValiosa
ADD CONSTRAINT fk_id_exposicao_obravaliosa
FOREIGN KEY (id_exposicao) REFERENCES Exposicao(id_exposicao);


ALTER TABLE ObraMaisValiosa
ADD CONSTRAINT fk_id_obra_obravaliosa
FOREIGN KEY (id_obra) REFERENCES ObraDeArte(id_obra);

ALTER TABLE ObraMaisValiosa
DROP CONSTRAINT fk_id_exposicao_obravaliosa;

ALTER TABLE ObraMaisValiosa
DROP CONSTRAINT fk_id_obra_obravaliosa;

DROP TABLE ObraMaisValiosa;
 
