use INF_20210775_2324;

--GUILHERME ISCA N�20210775
--JO�O DIAS N�20211714

--1) Qual o n�mero de visitas, por dia de semana, por obra de arte?
SELECT NomeObraArte,
    SUM(CASE WHEN NomeDiaSemanaAbrev = 'seg' THEN FV.NumeroVisitas END) AS Segunda,
    SUM(CASE WHEN NomeDiaSemanaAbrev = 'ter' THEN FV.NumeroVisitas END) AS Terca,
    SUM(CASE WHEN NomeDiaSemanaAbrev = 'qua' THEN FV.NumeroVisitas END) AS Quarta,
    SUM(CASE WHEN NomeDiaSemanaAbrev = 'qui' THEN FV.NumeroVisitas END) AS Quinta,
    SUM(CASE WHEN NomeDiaSemanaAbrev = 'sex' THEN FV.NumeroVisitas END) AS Sexta,
    SUM(CASE WHEN NomeDiaSemanaAbrev = 's�b' THEN FV.NumeroVisitas END) AS Sabado,
    SUM(CASE WHEN NomeDiaSemanaAbrev = 'dom' THEN FV.NumeroVisitas END) AS Domingo
FROM FatoVisitas fv
JOIN DimTempo t ON fv.ID_Tempo = t.ID_TEMPO
JOIN DimObraArte o ON fv.ID_ObraArte = o.ID_ObraArte
GROUP BY NomeObraArte
ORDER BY NomeObraArte;
--Chega-se � conclus�o que o maior n� de visitas foi nas obras 'Mona Lisa' e 'A Persist�ncia da Mem�ria', e
--que o dia da semana com mais visitas � no Sabado


--2) Qual a quantidade, por estado civil do visitante, de visitas por Artista?
SELECT a.NomeArtista,
    SUM(CASE WHEN v.EstadoCivil = 'Casado' THEN fv.NumeroVisitas END) as Casado,
    SUM(CASE WHEN v.EstadoCivil = 'Divorciado' THEN fv.NumeroVisitas END) as Divorciado,
    SUM(CASE WHEN v.EstadoCivil = 'Solteiro' THEN fv.NumeroVisitas END) as Solteiro
FROM DimArtista a
JOIN FatoVisitas fv ON a.ID_Artista = fv.ID_Artista
JOIN DimVisitante v ON fv.ID_Visitante = v.ID_Visitante
GROUP BY a.NomeArtista
ORDER BY a.NomeArtista;
--Chegamos � conclus�o que 'Vincent van Gogh' � o que tem mais visitantes
--e que a maioria dos visitantes � solteiro

--3)Qual o tempo m�dio de tempo dura��o e de avalia��o, por artista?
SELECT a.NomeArtista, 
	AVG(fv.DuracaoVisita) AS TempoMedioDuracao,
    AVG(fv.AvaliacaoVisita) AS AvaliacaoMedia
FROM FatoVisitas fv
JOIN DimArtista a ON fv.ID_Artista = a.ID_Artista
GROUP BY a.NomeArtista;

--Chegamos � conclus�o que 'Gustav Klimt' � o artista com mais tempo de dura��o m�dio
--e que ele � tamb�m o artista com melhor avalia��o media


--4) Quais os valores m�dios de recomenda��o a outros visitantes, por artista, por sexo de visitante?
SELECT da.NomeArtista,
    AVG(CASE WHEN dv.Sexo = 'Feminino' THEN fv.RecomendacaoVisita END) AS Feminino,
    AVG(CASE WHEN dv.Sexo = 'Masculino' THEN fv.RecomendacaoVisita END) AS Masculino
FROM FatoVisitas fv
JOIN DimArtista da ON fv.ID_Artista = da.ID_Artista
JOIN DimVisitante dv ON fv.ID_Visitante = dv.ID_Visitante
GROUP BY da.NomeArtista;

--Chega-se � conclus�o que 'Gustav Klimt' tem a melhor avalia��o masculina
--e 'Salvador Dal�' t�m a melhor avalia��o feminina




