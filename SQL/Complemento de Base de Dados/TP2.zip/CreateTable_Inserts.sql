use INF_20210775_2324;

--GUILHERME ISCA N�20210775
--JO�O DIAS N�20211714

----------------------------------CRIA��O DAS TABELAS-----------------------------------------------

-- Tabela Dimens�o de Tempo (DimTempo)
CREATE TABLE DimTempo (
    ID_TEMPO int IDENTITY(1,1) NOT NULL,
	data date NOT NULL,
    Ano smallint NOT NULL,
    Mes smallint, 
    Dia smallint, 
    DiaSemana smallint, 
	DiaAno smallint, 
	NomeDiaSemana varchar(15),
	NomeDiaSemanaAbrev char(3),
	NomeMes varchar(15),
	NomeMesAbrev varchar(3)
) on FG_F;

--Popula��o da tabela DimTempo

declare @dataInicial date, @dataFinal date, @data date,
		@ano smallint, @mes smallint, @dia smallint, 
		@diaSemana smallint, @nomeMes varchar(15),
		@nomeMesAbrev varchar(3),
		@nomeDiaSemana varchar(15), @nomeDiaSemanaAbrev char(3)
		
set @dataInicial = '01/Jan/2022'
set @dataFinal = '31/Dec/2022'

select * from DimTempo

while @dataInicial <= @dataFinal
begin
 set @data = @dataInicial
 set @ano = year(@data)
 set @mes = month(@data)
 set @dia = day(@data)
 set @diaSemana = datepart(weekday,@data)

 set @nomeMes = case when @mes = 1 then 'janeiro'
 when @mes = 2 then 'fevereiro'
 when @mes = 3 then 'mar�o'
 when @mes = 4 then 'abril'
 when @mes = 5 then 'maio'
 when @mes = 6 then 'junho'
 when @mes = 7 then 'julho'
 when @mes = 8 then 'agosto'
 when @mes = 9 then 'setembro'
 when @mes = 10 then 'outubro'
 when @mes = 11 then 'novembro'
 when @mes = 12 then 'dezembro' end

 set @nomeMesAbrev = case when @mes = 1 then 'jan'
 when @mes = 2 then 'fev'
 when @mes = 3 then 'mar'
 when @mes = 4 then 'abr'
 when @mes = 5 then 'mai'
 when @mes = 6 then 'jun'
 when @mes = 7 then 'jul'
 when @mes = 8 then 'ago'
 when @mes = 9 then 'set'
 when @mes = 10 then 'out'
 when @mes = 11 then 'nov'
 when @mes = 12 then 'dez' end

set @nomeDiaSemana = case when @diaSemana = 1 then 'domingo'
 when @diaSemana = 2 then 'segunda-feira'
 when @diaSemana = 3 then 'ter�a-feira'
 when @diaSemana = 4 then 'quarta-feira'
 when @diaSemana = 5 then 'quinta-feira'
 when @diaSemana = 6 then 'sexta-feira'
 else 's�bado' end

 set @nomeDiaSemanaAbrev = case when @diaSemana = 1 then 'dom'
 when @diaSemana = 2 then 'seg'
 when @diaSemana = 3 then 'ter'
 when @diaSemana = 4 then 'qua'
 when @diaSemana = 5 then 'qui'
 when @diaSemana = 6 then 'sex'
 else 's�b' end

INSERT INTO DimTempo
 SELECT @data
 ,@ano
 ,@mes
 ,@dia
 ,@diaSemana
 ,datepart(dayofyear,@data) --DIA_ANO
 ,@nomeDiaSemana
 ,@nomeDiaSemanaAbrev
 ,@nomeMes
 ,@nomeMesAbrev
 
 set @dataInicial = dateadd(day,1,@dataInicial) 
end

SELECT * FROM DimTempo;

alter table dimtempo
add constraint tb_dim_tempo_pk
primary key(id_tempo) on FG_G;
-- Tabela Dimens�o de Visitante (DimVisitante)
CREATE TABLE DimVisitante (
    ID_Visitante INT NOT NULL,
    EstadoCivil VARCHAR(20) CHECK (EstadoCivil IN ('Solteiro', 'Casado', 'Divorciado')),
    Sexo VARCHAR(10) CHECK (Sexo IN ('Masculino', 'Feminino'))
) on FG_F;



alter table dimvisitante
add constraint tb_dim_visitante_pk
primary key(id_visitante) on FG_G;

-- Tabela Dimens�o de Obra de Arte (DimObraArte)
CREATE TABLE DimObraArte (
    ID_ObraArte INT NOT NULL,
    NomeObraArte VARCHAR(100)
) on FG_F;

alter table dimobraarte
add constraint tb_dim_obraarte_pk
primary key(id_obraarte) on FG_G;

-- Tabela Dimens�o de Artista (DimArtista)
CREATE TABLE DimArtista (
    ID_Artista INT NOT NULL,
    NomeArtista VARCHAR(100)
) on FG_F;

alter table dimartista
add constraint tb_dim_artista_pk
primary key(id_artista) on FG_G;

-- Tabela de Fatos (FatoVisitas)
CREATE TABLE FatoVisitas (
    ID_Tempo INT,
    ID_ObraArte INT,
    ID_Visitante INT,
    ID_Artista INT,
    NumeroVisitas INT,
    DuracaoVisita INT,
    AvaliacaoVisita INT CHECK (AvaliacaoVisita BETWEEN 0 AND 20),
    RecomendacaoVisita INT CHECK (RecomendacaoVisita BETWEEN 0 AND 10),
    FOREIGN KEY (ID_Tempo) REFERENCES DimTempo(ID_Tempo),
    FOREIGN KEY (ID_ObraArte) REFERENCES DimObraArte(ID_ObraArte),
    FOREIGN KEY (ID_Visitante) REFERENCES DimVisitante(ID_Visitante),
    FOREIGN KEY (ID_Artista) REFERENCES DimArtista(ID_Artista)
) on PS_ParticaoPorIDVisitante(ID_Visitante);

----------------------------------INSER��O DE VALORES-----------------------------------------------

-- Inser��es na tabela DimVisitante
INSERT INTO DimVisitante VALUES (1, 'Solteiro', 'Masculino');
INSERT INTO DimVisitante VALUES (2, 'Casado', 'Feminino');
INSERT INTO DimVisitante VALUES (3, 'Divorciado', 'Masculino');
INSERT INTO DimVisitante VALUES (4, 'Solteiro', 'Feminino');
INSERT INTO DimVisitante VALUES (5, 'Casado', 'Masculino');
INSERT INTO DimVisitante VALUES (6, 'Divorciado', 'Feminino');
INSERT INTO DimVisitante VALUES (7, 'Solteiro', 'Masculino');
INSERT INTO DimVisitante VALUES (8, 'Casado', 'Feminino');
INSERT INTO DimVisitante VALUES (9, 'Divorciado', 'Masculino');
INSERT INTO DimVisitante VALUES (10, 'Solteiro', 'Feminino');

SELECT * FROM DimVisitante;

-- Inser��es na tabela DimObraArte
INSERT INTO DimObraArte VALUES (1, 'Mona Lisa');
INSERT INTO DimObraArte VALUES (2, 'A Noite Estrelada');
INSERT INTO DimObraArte VALUES (3, 'Guernica');
INSERT INTO DimObraArte VALUES (4, 'O Grito');
INSERT INTO DimObraArte VALUES (5, 'Os Girass�is');
INSERT INTO DimObraArte VALUES (6, 'A Persist�ncia da Mem�ria');
INSERT INTO DimObraArte VALUES (7, 'O Nascimento de V�nus');
INSERT INTO DimObraArte VALUES (8, 'O Beijo');
INSERT INTO DimObraArte VALUES (9, 'A �ltima Ceia');
INSERT INTO DimObraArte VALUES (10, 'O Pensador');

SELECT * FROM DimObraArte;

-- Inser��es na tabela DimArtista
INSERT INTO DimArtista VALUES (1, 'Leonardo da Vinci');
INSERT INTO DimArtista VALUES (2, 'Vincent van Gogh');
INSERT INTO DimArtista VALUES (3, 'Pablo Picasso');
INSERT INTO DimArtista VALUES (4, 'Edvard Munch');
INSERT INTO DimArtista VALUES (5, 'Vincent van Gogh');
INSERT INTO DimArtista VALUES (6, 'Salvador Dal�');
INSERT INTO DimArtista VALUES (7, 'Sandro Botticelli');
INSERT INTO DimArtista VALUES (8, 'Gustav Klimt');
INSERT INTO DimArtista VALUES (9, 'Leonardo da Vinci');
INSERT INTO DimArtista VALUES (10, 'Auguste Rodin');

SELECT * FROM DimArtista;

-- Inser��es na tabela FatoVisitas
INSERT INTO FatoVisitas (ID_Tempo, ID_ObraArte, ID_Visitante, ID_Artista, NumeroVisitas, DuracaoVisita, AvaliacaoVisita, RecomendacaoVisita)
VALUES
  (1, 1, 1, 1, 10, 30, 15, 8),
  (22, 2, 2, 2, 15, 45, 18, 9),
  (34, 3, 3, 3, 8, 20, 12, 6),
  (50, 4, 4, 4, 12, 35, 16, 7),
  (65, 5, 5, 5, 5, 15, 10, 5),
  (76, 6, 6, 6, 18, 50, 20, 10),
  (100, 7, 7, 7, 9, 25, 14, 7),
  (119, 8, 8, 8, 14, 40, 17, 8),
  (137, 9, 9, 9, 7, 18, 11, 6),
  (146, 10, 10, 10, 20, 55, 19, 9),
  (170, 1, 2, 3, 11, 32, 14, 7),
  (190, 2, 3, 4, 16, 47, 16, 8),
  (179, 3, 4, 5, 9, 22, 13, 6),
  (210, 4, 5, 6, 13, 38, 18, 9),
  (233, 5, 6, 7, 6, 16, 9, 4),
  (242, 6, 7, 8, 19, 53, 20, 10),
  (270, 7, 8, 9, 10, 28, 15, 7),
  (285, 8, 9, 10, 15, 43, 17, 8),
  (300, 9, 10, 1, 8, 20, 11, 5),
  (320, 10, 1, 2, 22, 58, 19, 9),
  (331, 1, 2, 3, 13, 36, 15, 7),
  (343, 2, 3, 4, 18, 51, 18, 8),
  (362, 3, 4, 5, 11, 26, 13, 6),
  (124, 4, 5, 6, 15, 41, 17, 8),
  (225, 5, 6, 7, 8, 18, 10, 5),
  (260, 6, 7, 8, 21, 56, 20, 10),
  (27, 7, 8, 9, 12, 30, 16, 7),
  (48, 8, 9, 10, 17, 45, 18, 9),
  (99, 9, 10, 1, 10, 22, 12, 6),
  (60, 1, 1, 2, 24, 60, 20, 10);


SELECT * FROM FatoVisitas;

------------------------------------------------DROPs/DELETEs-----------------------------------------------

DROP TABLE FatoVisitas;
DROP TABLE DimTempo;
DROP TABLE DimVisitante;
DROP TABLE DimObraArte;
DROP TABLE DimArtista;

DELETE FROM DimVisitante;
DELETE FROM DimObraArte;
DELETE FROM DimArtista;