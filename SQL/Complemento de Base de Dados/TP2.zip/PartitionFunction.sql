use INF_20210775_2324;

--GUILHERME ISCA N�20210775
--JO�O DIAS N�20211714

-- Fun��o de Particionamento por ID de Visitante
CREATE PARTITION FUNCTION particaoPorIDVisitante (INT)
AS RANGE LEFT FOR VALUES (50);

-- Esquema de Particionamento por ID de Visitante
CREATE PARTITION SCHEME PS_ParticaoPorIDVisitante
AS PARTITION particaoPorIDVisitante TO (fg_h, fg_i);